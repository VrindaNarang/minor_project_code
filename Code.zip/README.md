# Carbon-aware model selection: experiment code

Fashion-MNIST, three tiers (logistic regression, MLP 784-128-10, CNN conv16-conv32-fc10),
all in PyTorch on the CPU, plus a scikit-learn logistic regression as a reference.
CodeCarbon measures every training run and inference block; eco2AI re-measures one of each per tier.

## Run (macOS)
    bash run_all.sh --quick     # 3 min: installs, runs a tiny version, makes figures
    bash run_all.sh             # full protocol, about 1-2 h

Before the full run: plug in the charger, close other apps, turn off Low Power Mode,
and don't use the laptop while it runs. `caffeinate` keeps it awake.

## Output
    results/<timestamp>/                 raw CSV logs (one row per measurement) + environment.json
    results/<timestamp>/analysis/figures 12 figures, PDF + PNG
    results/<timestamp>/analysis/tables  LaTeX tables for Chapter 5 (\input them)
    results/<timestamp>/analysis/summary.json   every number used in the text

## What the protocol does (Chapter 3)
- 5 rounds, tier order rotated each round; 30 s idle baseline at the start of each round
- training: Adam, lr 1e-3, batch 64, 10 epochs, seeds 1000-1004
- inference: 100 warm-up calls, then M single-sample calls, with M set so a block lasts at least 60 s
- net energy = measured - idle power x duration
- crossover N* = (E_train,B - E_train,A) / (E_infer,A - E_infer,B), with a 10,000-sample bootstrap
- `--tune` also logs a small learning-rate sweep separately (cost of experimentation)

---

# Extended study (paper: "Train or Reuse?")

Seven tiers (LR, MLP, CNN, int8 CNN, k-NN, RBF SVM, random forest) on Fashion-MNIST and
SMS Spam, 10 rounds, with package power read from Apple's `powermetrics`; plus a zero-shot
session comparing Strands Decider 2B with trained scikit-learn tiers on Iris, Breast Cancer,
Wine and SMS Spam (5 rounds).

## Files
| File | What it does |
|---|---|
| `extended.py` | SMS loading/vocabulary, text models, int8 quantisation, scikit-learn tier builders, phase logger |
| `run_extended.py` | Main study (setup, single-sample and batched inference blocks per tier and round) |
| `run_addon.py` | Zero-shot session: starts the Decider server, scores test sets, measures blocks |
| `parse_powermetrics.py` | Parses the `powermetrics` plist stream and integrates power over each logged phase |
| `analyze_extended.py` | Paired bootstrap, crossovers, selector, McNemar tests, CO2e, tables, figures, `summary.json` |

## Run (macOS, Apple silicon)
In a separate terminal, start power sampling (needs administrator rights):

    sudo powermetrics -i 1000 --samplers cpu_power,gpu_power,thermal -f plist -o results_ext/powermetrics.plist

Then:

    .venv/bin/python run_extended.py --out results_ext            # about 5 h
    # zero-shot session (Decider in its own venv: pip install strands-decider)
    .venv/bin/python run_addon.py --out results_addon --decider-python <venv>/bin/strands-decider
    # stop powermetrics, then
    .venv/bin/python parse_powermetrics.py results_ext/<run>   --plist results_ext/powermetrics.plist
    .venv/bin/python parse_powermetrics.py results_addon/<run> --plist results_ext/powermetrics.plist
    .venv/bin/python analyze_extended.py results_ext/<run> --addon results_addon/<run> --out <paper dir>

`--quick` on either run script does a short smoke test. PyTorch's NNPACK backend is disabled
by default (`--nnpack` re-enables it).

## Included measured runs
`results_ext/20261110-202517/` and `results_addon/20261111-015010/` contain the phase logs,
per-sample power (`power_samples.csv`), per-phase power (`phase_power.csv`) and test predictions
from the runs reported in the paper. The raw `powermetrics.plist` (1.2 GB) is not included;
`power_samples.csv` holds every parsed sample. `results/20261103-201248/` is the pilot run.
