"""Run the full measurement protocol of Chapter 3.

For every round r = 0..R-1 (tiers interleaved in a rotating order):
    idle baseline  ->  for each tier: train (tracked) -> evaluate (untracked)
                       -> warm-up -> inference block of M single-sample calls (tracked)
Afterwards: one eco2AI cross-check training run and inference block per tier.

Every measurement is appended to a CSV as soon as it is taken, so a crash
or Ctrl-C keeps everything recorded up to that point.

Usage:
    python run_experiment.py                 # full run (about 1-2 h on a laptop)
    python run_experiment.py --quick         # 3-minute smoke test
"""
import argparse
import csv
import math
import os
import time
from datetime import datetime

import numpy as np
import torch
import torch.nn as nn
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score

from common import (TIERS, CCTracker, Eco2AITracker, build_model, count_macs, count_params,
                    describe_environment, load_fashion_mnist, save_json, set_seed)


def parse():
    p = argparse.ArgumentParser()
    p.add_argument("--out", default="results")
    p.add_argument("--data", default="data")
    p.add_argument("--runs", type=int, default=5)
    p.add_argument("--epochs", type=int, default=10)
    p.add_argument("--batch", type=int, default=64)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--threads", type=int, default=4)
    p.add_argument("--min-block-s", type=float, default=60.0, help="minimum length of one inference block")
    p.add_argument("--min-calls", type=int, default=10000)
    p.add_argument("--warmup", type=int, default=100)
    p.add_argument("--idle-s", type=float, default=30.0)
    p.add_argument("--interval", type=float, default=1.0, help="tracker sampling interval (s)")
    p.add_argument("--country", default="IND")
    p.add_argument("--tune", action="store_true", help="log the energy of a small learning-rate sweep first")
    p.add_argument("--no-eco2ai", action="store_true")
    p.add_argument("--no-sklearn", action="store_true")
    p.add_argument("--train-subset", type=int, default=0, help="use only this many training images (testing only)")
    p.add_argument("--quick", action="store_true", help="tiny settings to check that everything works")
    a = p.parse_args()
    if a.quick:
        a.runs, a.epochs, a.min_block_s, a.min_calls, a.idle_s = 2, 1, 4.0, 2000, 3.0
        a.train_subset = a.train_subset or 6000
    return a


class CSVLog:
    def __init__(self, path):
        self.path = path
        self.header = None

    def write(self, row):
        new = not os.path.exists(self.path)
        if self.header is None:
            self.header = list(row.keys())
        with open(self.path, "a", newline="") as f:
            w = csv.DictWriter(f, fieldnames=self.header)
            if new:
                w.writeheader()
            w.writerow(row)


# ------------------------------------------------------------------ training
def evaluate(model, x, y, bs=1000):
    model.eval()
    preds = []
    with torch.inference_mode():
        for i in range(0, len(x), bs):
            preds.append(model(x[i:i + bs]).argmax(1))
    p = torch.cat(preds)
    return (p == y).float().mean().item(), p


def train_torch(tier, D, seed, epochs, bs, lr, tracker):
    """Train one model inside `tracker`; return the model and a per-epoch log."""
    set_seed(seed)
    model = build_model(tier)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.CrossEntropyLoss()
    x, y = D["x_train"], D["y_train"]
    g = torch.Generator().manual_seed(seed)
    epoch_log = []
    with tracker:
        t0 = time.perf_counter()
        for ep in range(1, epochs + 1):
            model.train()
            perm = torch.randperm(len(x), generator=g)
            total = 0.0
            for i in range(0, len(x), bs):
                idx = perm[i:i + bs]
                opt.zero_grad(set_to_none=True)
                loss = loss_fn(model(x[idx]), y[idx])
                loss.backward()
                opt.step()
                total += loss.item() * len(idx)
            t_train = time.perf_counter() - t0
            val_acc, _ = evaluate(model, D["x_val"], D["y_val"])
            epoch_log.append({"epoch": ep, "train_loss": total / len(x), "val_acc": val_acc,
                              "elapsed_s": t_train})
    return model, epoch_log


def train_sklearn(D, seed, tracker):
    X = D["x_train"].flatten(1).numpy()
    y = D["y_train"].numpy()
    with tracker:
        clf = LogisticRegression(max_iter=1000, random_state=seed)
        clf.fit(X, y)
    return clf


# ----------------------------------------------------------------- inference
def make_inputs(D, n=1000):
    return [D["x_test"][i:i + 1].contiguous() for i in range(n)]


def make_inputs_np(D, n=1000):
    X = D["x_test"][:n].flatten(1).numpy()
    return [X[i:i + 1].copy() for i in range(n)]


def infer_loop(predict, inputs, m):
    n = len(inputs)
    for i in range(m):
        predict(inputs[i % n])


def torch_predictor(model):
    model.eval()

    def f(x):
        with torch.inference_mode():
            return model(x).argmax(1).item()
    return f


def sk_predictor(clf):
    return lambda x: int(clf.predict(x)[0])


def calibrate_calls(predict, inputs, min_block_s, min_calls):
    infer_loop(predict, inputs, 200)
    t0 = time.perf_counter()
    infer_loop(predict, inputs, 2000)
    per_call = (time.perf_counter() - t0) / 2000
    m = max(min_calls, math.ceil(min_block_s / per_call))
    return int(math.ceil(m / 1000) * 1000), per_call


# ---------------------------------------------------------------------- main
def main():
    a = parse()
    torch.set_num_threads(a.threads)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    out = os.path.join(a.out, stamp + ("-quick" if a.quick else ""))
    os.makedirs(out, exist_ok=True)
    print(f"Writing results to {out}")

    env = describe_environment(a.threads)
    env["args"] = vars(a)
    env["started"] = datetime.now().isoformat()
    save_json(env, os.path.join(out, "environment.json"))

    D = load_fashion_mnist(a.data)
    if a.train_subset:
        D["x_train"], D["y_train"] = D["x_train"][:a.train_subset], D["y_train"][:a.train_subset]
    np.savez_compressed(os.path.join(out, "split_indices.npz"),
                        train=np.array(D["split_indices"]["train"]), val=np.array(D["split_indices"]["val"]))
    print(f"Data: train {len(D['x_train'])}, val {len(D['x_val'])}, test {len(D['x_test'])}")

    tiers = list(TIERS)
    use_sk = not a.no_sklearn
    seeds = [1000 + r for r in range(a.runs)]

    logs = {k: CSVLog(os.path.join(out, f"{k}.csv"))
            for k in ["train_runs", "epoch_log", "inference_blocks", "idle", "tuning", "crosscheck"]}

    inputs_t = make_inputs(D)
    inputs_np = make_inputs_np(D)
    y_test = D["y_test"]

    # ---- static model facts
    facts = {t: {"params": count_params(build_model(t)), "macs": count_macs(t)} for t in tiers}
    if use_sk:
        facts["sk_logreg"] = {"params": 7850, "macs": count_macs("sk_logreg")}
    save_json(facts, os.path.join(out, "model_facts.json"))

    # ---- number of calls per inference block (fixed for every round)
    block_calls = {}
    for t in tiers:
        m, pc = calibrate_calls(torch_predictor(build_model(t)), inputs_t, a.min_block_s, a.min_calls)
        block_calls[t] = m
        print(f"  {t:10s} ~{pc * 1e6:8.1f} us/call -> M = {m:,}")

    # ---- optional learning-rate sweep (experimentation cost, logged separately)
    if a.tune:
        tune_epochs = max(1, a.epochs // 3)
        for t in tiers:
            for lr in [3e-4, 1e-3, 3e-3]:
                tr = CCTracker(a.country, a.interval, out)
                model, ep = train_torch(t, D, 7, tune_epochs, a.batch, lr, tr)
                logs["tuning"].write({"tier": t, "lr": lr, "epochs": tune_epochs,
                                      "val_acc": ep[-1]["val_acc"], **tr.result})
                print(f"  tune {t} lr={lr:g}: val {ep[-1]['val_acc']:.4f}, {tr.result['energy_kwh'] * 1000:.3f} Wh")

    # ---- main rounds
    for r, seed in enumerate(seeds):
        order = tiers[r % len(tiers):] + tiers[:r % len(tiers)]
        print(f"\n=== Round {r + 1}/{a.runs}  seed {seed}  order {order}")

        tr = CCTracker(a.country, a.interval, out)
        with tr:
            time.sleep(a.idle_s)
        logs["idle"].write({"round": r, "when": "start", **tr.result})
        idle_power_w = tr.result["energy_kwh"] * 3.6e6 / tr.result["duration_s"]
        print(f"  idle: {idle_power_w:.2f} W")

        for t in order:
            tr = CCTracker(a.country, a.interval, out)
            model, ep_log = train_torch(t, D, seed, a.epochs, a.batch, a.lr, tr)
            acc, preds = evaluate(model, D["x_test"], y_test)
            f1 = f1_score(y_test.numpy(), preds.numpy(), average="macro")
            best = max(ep_log, key=lambda e: e["val_acc"])
            logs["train_runs"].write({"round": r, "seed": seed, "tier": t, "epochs": a.epochs,
                                      "test_acc": acc, "test_f1": f1, "best_val_epoch": best["epoch"],
                                      "best_val_acc": best["val_acc"],
                                      "idle_power_w": idle_power_w, "tracker": tr.method, **tr.result})
            for e in ep_log:
                logs["epoch_log"].write({"round": r, "tier": t, **e})
            if r == 0:
                np.save(os.path.join(out, f"test_preds_{t}.npy"), preds.numpy())
            print(f"  train {t:8s} {tr.result['duration_s']:7.1f}s  {tr.result['energy_kwh'] * 1000:8.3f} Wh  "
                  f"acc {acc:.4f}")

            pred = torch_predictor(model)
            infer_loop(pred, inputs_t, a.warmup)
            tr = CCTracker(a.country, a.interval, out)
            with tr:
                infer_loop(pred, inputs_t, block_calls[t])
            logs["inference_blocks"].write({"round": r, "tier": t, "calls": block_calls[t],
                                            "idle_power_w": idle_power_w, **tr.result})
            print(f"  infer {t:8s} {tr.result['duration_s']:7.1f}s  "
                  f"{tr.result['energy_kwh'] * 3.6e9 / block_calls[t]:9.3f} mJ/call gross")

        if use_sk:
            tr = CCTracker(a.country, a.interval, out)
            clf = train_sklearn(D, seed, tr)
            p = clf.predict(D["x_test"].flatten(1).numpy())
            acc = float((p == y_test.numpy()).mean())
            f1 = f1_score(y_test.numpy(), p, average="macro")
            logs["train_runs"].write({"round": r, "seed": seed, "tier": "sk_logreg", "epochs": None,
                                      "test_acc": acc, "test_f1": f1, "best_val_epoch": None,
                                      "best_val_acc": None, "idle_power_w": idle_power_w,
                                      "tracker": tr.method, **tr.result})
            if r == 0:
                np.save(os.path.join(out, "test_preds_sk_logreg.npy"), p)
                block_calls["sk_logreg"], _ = calibrate_calls(sk_predictor(clf), inputs_np,
                                                              a.min_block_s, a.min_calls)
            pred = sk_predictor(clf)
            infer_loop(pred, inputs_np, a.warmup)
            tr2 = CCTracker(a.country, a.interval, out)
            with tr2:
                infer_loop(pred, inputs_np, block_calls["sk_logreg"])
            logs["inference_blocks"].write({"round": r, "tier": "sk_logreg", "calls": block_calls["sk_logreg"],
                                            "idle_power_w": idle_power_w, **tr2.result})
            print(f"  sklearn LR: train {tr.result['duration_s']:.1f}s, acc {acc:.4f}")

    # ---- idle again at the end, to see drift
    tr = CCTracker(a.country, a.interval, out)
    with tr:
        time.sleep(a.idle_s)
    logs["idle"].write({"round": a.runs, "when": "end", **tr.result})

    # ---- eco2AI cross-check: same work measured by the second tool
    if not a.no_eco2ai:
        eco_dir = os.path.join(out, "eco2ai_raw")
        os.makedirs(eco_dir, exist_ok=True)
        for t in tiers:
            try:
                tr = Eco2AITracker(os.path.join(eco_dir, f"train-{t}.csv"), f"train-{t}")
                model, _ = train_torch(t, D, 999, a.epochs, a.batch, a.lr, tr)
                logs["crosscheck"].write({"tool": "eco2ai", "phase": "train", "tier": t, "calls": None, **tr.result})
                pred = torch_predictor(model)
                infer_loop(pred, inputs_t, a.warmup)
                tr = Eco2AITracker(os.path.join(eco_dir, f"infer-{t}.csv"), f"infer-{t}")
                with tr:
                    infer_loop(pred, inputs_t, block_calls[t])
                logs["crosscheck"].write({"tool": "eco2ai", "phase": "infer", "tier": t,
                                          "calls": block_calls[t], **tr.result})
                print(f"  eco2AI {t}: done")
            except Exception as e:  # report, never hide
                print(f"  eco2AI {t} failed: {e!r}")
                logs["crosscheck"].write({"tool": "eco2ai", "phase": "error", "tier": t, "calls": None,
                                          "duration_s": None, "energy_kwh": None, "emissions_kg": repr(e)})

    env["finished"] = datetime.now().isoformat()
    env["block_calls"] = block_calls
    save_json(env, os.path.join(out, "environment.json"))
    print(f"\nDone. Now run:  python analyze.py {out}")


if __name__ == "__main__":
    main()
