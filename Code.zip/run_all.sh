#!/usr/bin/env bash
# One command to set up, smoke-test, run the full experiment and analyse it.
# Usage:  bash run_all.sh            (full run, roughly 1-2 hours)
#         bash run_all.sh --quick    (3-minute check only)
set -euo pipefail
cd "$(dirname "$0")"

if [ ! -d .venv ]; then
  python3 -m venv .venv
  .venv/bin/pip install --upgrade pip -q
  .venv/bin/pip install -r requirements.txt -q
fi
PY=.venv/bin/python

echo ">> Smoke test"
$PY run_experiment.py --quick --out results_quick
$PY analyze.py "$(ls -d results_quick/*-quick | tail -1)"
[ "${1:-}" = "--quick" ] && exit 0

echo ">> Full run. Keep the laptop on mains power, lid open, other apps closed."
CAF=""; command -v caffeinate >/dev/null && CAF="caffeinate -dimsu"
$CAF $PY run_experiment.py --tune --out results 2>&1 | tee results_log.txt
$PY analyze.py "$(ls -d results/2* | tail -1)"
