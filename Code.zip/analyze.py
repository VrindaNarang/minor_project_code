"""Turn the raw logs of run_experiment.py into numbers, figures and LaTeX tables.

    python analyze.py results/<run-folder>

Writes into <run-folder>/analysis/:
    figures/*.pdf (+ .png)   -> copy into the report's Figures/ folder
    tables/*.tex             -> \\input{} from Chapter 5
    summary.json             -> every number quoted in the text
"""
import itertools
import json
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import ListedColormap
from scipy import stats

TIERS = ["logreg", "mlp", "cnn"]
LABEL = {"logreg": "Logistic regression", "mlp": "MLP", "cnn": "Small CNN",
         "sk_logreg": "scikit-learn LR"}
SHORT = {"logreg": "LR", "mlp": "MLP", "cnn": "CNN", "sk_logreg": "sk-LR"}
COLOR = {"logreg": "#2a78d6", "mlp": "#eb6834", "cnn": "#1baf7a", "sk_logreg": "#8a8984"}
INK, INK2, GRID = "#0b0b0b", "#52514e", "#e4e3df"
RNG = np.random.default_rng(12345)
N_BOOT = 10_000

plt.rcParams.update({
    "font.family": "serif", "font.size": 10, "axes.edgecolor": INK2, "axes.labelcolor": INK,
    "xtick.color": INK2, "ytick.color": INK2, "axes.spines.top": False, "axes.spines.right": False,
    "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6, "axes.axisbelow": True,
    "legend.frameon": False, "savefig.bbox": "tight", "figure.dpi": 110,
})


# ------------------------------------------------------------------ helpers
def ci95(x):
    x = np.asarray(x, float)
    x = x[~np.isnan(x)]
    if len(x) < 2:
        return np.nan
    return stats.t.ppf(0.975, len(x) - 1) * x.std(ddof=1) / np.sqrt(len(x))


def describe(x):
    x = np.asarray(x, float)
    return {"mean": float(np.mean(x)), "sd": float(np.std(x, ddof=1)) if len(x) > 1 else 0.0,
            "ci95": float(ci95(x)), "cv": float(np.std(x, ddof=1) / np.mean(x)) if len(x) > 1 and np.mean(x) else 0.0,
            "n": int(len(x)), "values": [float(v) for v in x]}


def fmt(v, sig=3):
    """Plain number with `sig` significant figures, thousands separators for big values."""
    if v is None or (isinstance(v, float) and not np.isfinite(v)):
        return "--"
    if v == 0:
        return "0"
    mag = int(np.floor(np.log10(abs(v))))
    if mag >= 6:
        m = v / 10 ** mag
        return f"${m:.2f}\\times10^{{{mag}}}$"
    if mag >= 3:
        return f"{v:,.0f}".replace(",", "{,}")
    dec = max(0, sig - 1 - mag)
    return f"{v:.{dec}f}"


def fmt_n(v):
    if v is None or not np.isfinite(v):
        return "--"
    if v < 1:
        return "$<1$"
    return fmt(v)


def save(fig, figdir, name):
    fig.savefig(os.path.join(figdir, name + ".pdf"))
    fig.savefig(os.path.join(figdir, name + ".png"), dpi=200)
    plt.close(fig)


def write_table(tabdir, name, caption, label, colspec, header, rows, note=None):
    lines = ["\\begin{table}[H]", "\\centering", f"\\caption{{{caption}}}", f"\\label{{{label}}}",
             "\\small", "\\begin{adjustbox}{max width=\\linewidth}", f"\\begin{{tabular}}{{{colspec}}}", "\\hline", " & ".join(header) + " \\\\", "\\hline"]
    lines += [" & ".join(str(c) for c in r) + " \\\\" for r in rows]
    lines += ["\\hline", "\\end{tabular}", "\\end{adjustbox}"]
    if note:
        lines += ["\\par\\vspace{2pt}", f"\\parbox{{0.92\\linewidth}}{{\\footnotesize {note}}}"]
    lines += ["\\end{table}", ""]
    with open(os.path.join(tabdir, name + ".tex"), "w") as f:
        f.write("\n".join(lines))


def classify(a_tr, a_in, b_tr, b_in):
    """Crossover between tier A and tier B. Energies in Wh. Returns (case, N*)."""
    d_tr, d_in = b_tr - a_tr, a_in - b_in
    if d_in == 0:
        return "parallel", np.nan
    n = d_tr / d_in
    if n > 0:
        return "crossover", n
    return "dominance", np.nan


# --------------------------------------------------------------------- main
def main(run_dir):
    out = os.path.join(run_dir, "analysis")
    figdir, tabdir = os.path.join(out, "figures"), os.path.join(out, "tables")
    os.makedirs(figdir, exist_ok=True)
    os.makedirs(tabdir, exist_ok=True)

    env = json.load(open(os.path.join(run_dir, "environment.json")))
    facts = json.load(open(os.path.join(run_dir, "model_facts.json")))
    tr = pd.read_csv(os.path.join(run_dir, "train_runs.csv"))
    inf = pd.read_csv(os.path.join(run_dir, "inference_blocks.csv"))
    idle = pd.read_csv(os.path.join(run_dir, "idle.csv"))
    ep = pd.read_csv(os.path.join(run_dir, "epoch_log.csv"))
    cc_path = os.path.join(run_dir, "crosscheck.csv")
    cc = pd.read_csv(cc_path) if os.path.exists(cc_path) else pd.DataFrame()
    tune_path = os.path.join(run_dir, "tuning.csv")
    tune = pd.read_csv(tune_path) if os.path.exists(tune_path) else pd.DataFrame()

    tiers_all = [t for t in TIERS + ["sk_logreg"] if t in set(tr["tier"])]

    # ---- derived quantities
    idle["power_w"] = idle["energy_kwh"] * 3.6e6 / idle["duration_s"]
    tr["E_gross_wh"] = tr["energy_kwh"] * 1e3
    tr["E_net_wh"] = tr["E_gross_wh"] - tr["idle_power_w"] * tr["duration_s"] / 3600
    inf["e_gross_uwh"] = inf["energy_kwh"] * 1e9 / inf["calls"]
    inf["e_net_uwh"] = (inf["energy_kwh"] * 1e9 - inf["idle_power_w"] * inf["duration_s"] / 3600 * 1e6) / inf["calls"]
    inf["latency_us"] = inf["duration_s"] / inf["calls"] * 1e6
    intensity = float((tr["emissions_kg"] / tr["energy_kwh"]).median())  # kg CO2e per kWh

    S = {"environment": env, "intensity_kg_per_kwh": intensity,
         "idle_power_w": describe(idle["power_w"]), "tiers": {}, "tracker_method": tr["tracker"].iloc[0]}
    for t in tiers_all:
        a, b = tr[tr.tier == t], inf[inf.tier == t]
        S["tiers"][t] = {
            "params": facts[t]["params"], "macs": facts[t]["macs"],
            "train_gross_wh": describe(a.E_gross_wh), "train_net_wh": describe(a.E_net_wh),
            "train_time_s": describe(a.duration_s), "train_co2_g": describe(a.emissions_kg * 1e3),
            "train_cpu_wh": describe(a.cpu_energy_kwh * 1e3), "train_ram_wh": describe(a.ram_energy_kwh * 1e3),
            "infer_gross_uwh": describe(b.e_gross_uwh), "infer_net_uwh": describe(b.e_net_uwh),
            "latency_us": describe(b.latency_us), "calls_per_block": int(b.calls.iloc[0]),
            "infer_co2_ug": describe(b.emissions_kg * 1e9 / b.calls),
            "test_acc": describe(a.test_acc), "test_f1": describe(a.test_f1),
        }
        if t != "sk_logreg":
            S["tiers"][t]["best_val_epoch"] = describe(a.best_val_epoch)

    # ---- crossovers (net = primary, gross = check), with bootstrap
    S["crossover"] = {}
    for basis in ["net", "gross"]:
        S["crossover"][basis] = {}
        for A, B in itertools.combinations(TIERS, 2):
            tA, tB = tr[tr.tier == A][f"E_{basis}_wh"].values, tr[tr.tier == B][f"E_{basis}_wh"].values
            iA = inf[inf.tier == A][f"e_{basis}_uwh"].values * 1e-6
            iB = inf[inf.tier == B][f"e_{basis}_uwh"].values * 1e-6
            case, n = classify(tA.mean(), iA.mean(), tB.mean(), iB.mean())
            boots, cases = [], []
            for _ in range(N_BOOT):
                c, nb = classify(RNG.choice(tA, len(tA)).mean(), RNG.choice(iA, len(iA)).mean(),
                                 RNG.choice(tB, len(tB)).mean(), RNG.choice(iB, len(iB)).mean())
                cases.append(c)
                if c == "crossover":
                    boots.append(nb)
            boots = np.array(boots)
            # who wins where
            if case == "crossover":
                low_n = A if tA.mean() < tB.mean() else B
                high_n = B if low_n == A else A
                winner = f"{SHORT[low_n]} below $N^*$, {SHORT[high_n]} above"
            else:
                tot = lambda tt, ii: tt.mean() + 1e6 * ii.mean()
                winner = SHORT[A] if tot(tA, iA) < tot(tB, iB) else SHORT[B]
                winner = f"{winner} at every $N$"
            S["crossover"][basis][f"{A}-{B}"] = {
                "A": A, "B": B, "case": case, "n_star": float(n) if np.isfinite(n) else None,
                "p_crossover": cases.count("crossover") / N_BOOT,
                "boot_lo": float(np.percentile(boots, 2.5)) if len(boots) > 50 else None,
                "boot_hi": float(np.percentile(boots, 97.5)) if len(boots) > 50 else None,
                "d_train_wh": float(tB.mean() - tA.mean()), "d_infer_uwh": float((iA.mean() - iB.mean()) * 1e6),
                "winner": winner,
            }

    # ---- numerical check of the crossovers on a log grid
    grid = np.logspace(0, 10, 4001)
    num = {}
    for key, c in S["crossover"]["net"].items():
        A, B = c["A"], c["B"]
        eA = S["tiers"][A]["train_net_wh"]["mean"] + grid * S["tiers"][A]["infer_net_uwh"]["mean"] * 1e-6
        eB = S["tiers"][B]["train_net_wh"]["mean"] + grid * S["tiers"][B]["infer_net_uwh"]["mean"] * 1e-6
        flips = np.where(np.diff(np.sign(eA - eB)) != 0)[0]
        num[key] = float(grid[flips[0] + 1]) if len(flips) else None
    S["crossover_numerical_net"] = num

    # ---- decision framework
    def recommend(N, amin, basis="net"):
        best, best_e = None, np.inf
        for t in TIERS:
            d = S["tiers"][t]
            if d["test_acc"]["mean"] < amin:
                continue
            e = d[f"train_{basis}_wh"]["mean"] + N * d[f"infer_{basis}_uwh"]["mean"] * 1e-6
            if e < best_e:
                best, best_e = t, e
        return best, best_e

    accs = {t: S["tiers"][t]["test_acc"]["mean"] for t in TIERS}
    volumes = [1e3, 1e5, 1e6, 1e7, 1e8, 1e9]
    thresholds = sorted({0.0} | {round(np.floor(a * 1000) / 1000, 3) for a in accs.values()})
    S["decision_table"] = []
    for amin in thresholds:
        row = {"amin": amin, "rec": {}}
        for N in volumes:
            t, e = recommend(N, amin)
            row["rec"][f"{N:.0e}"] = t
        S["decision_table"].append(row)

    # ---- H2: which gap moves N* more? vary each gap by +-1 sd
    S["h2"] = {}
    for key, c in S["crossover"]["net"].items():
        if c["case"] != "crossover":
            continue
        A, B = c["A"], c["B"]
        dA, dB = S["tiers"][A], S["tiers"][B]
        d_tr = c["d_train_wh"]
        d_in = c["d_infer_uwh"] * 1e-6
        sd_tr = np.hypot(dA["train_net_wh"]["sd"], dB["train_net_wh"]["sd"])
        sd_in = np.hypot(dA["infer_net_uwh"]["sd"], dB["infer_net_uwh"]["sd"]) * 1e-6
        S["h2"][key] = {
            "n_star": d_tr / d_in,
            "vary_train": [(d_tr - sd_tr) / d_in, (d_tr + sd_tr) / d_in],
            "vary_infer": [d_tr / (d_in + sd_in), d_tr / (d_in - sd_in) if d_in - sd_in > 0 else None],
            "rel_sd_train_gap": float(sd_tr / abs(d_tr)) if d_tr else None,
            "rel_sd_infer_gap": float(sd_in / abs(d_in)) if d_in else None,
        }

    # ---- carbon sensitivity (different grids for training and serving)
    S["co2_sensitivity"] = {}
    for key, c in S["crossover"]["net"].items():
        if c["n_star"]:
            S["co2_sensitivity"][key] = {str(r): c["n_star"] * r for r in [1.0, 0.5, 0.25, 0.1]}

    # ---- eco2AI cross-check
    if not cc.empty and "phase" in cc and (cc.phase != "error").any():
        ok = cc[cc.phase != "error"].copy()
        S["crosscheck"] = {}
        for _, r in ok.iterrows():
            t = r["tier"]
            if r["phase"] == "train":
                cc_val = S["tiers"][t]["train_gross_wh"]["mean"]
                eco_val = r["energy_kwh"] * 1e3
            else:
                cc_val = S["tiers"][t]["infer_gross_uwh"]["mean"]
                eco_val = r["energy_kwh"] * 1e9 / r["calls"]
            S["crosscheck"].setdefault(t, {})[r["phase"]] = {"codecarbon": cc_val, "eco2ai": eco_val,
                                                              "ratio": eco_val / cc_val if cc_val else None}
        rank = lambda phase, tool: [t for t, _ in sorted(((t, S["crosscheck"][t][phase][tool])
                                                           for t in S["crosscheck"] if phase in S["crosscheck"][t]),
                                                          key=lambda z: z[1])]
        S["crosscheck_rank_agree"] = {ph: rank(ph, "codecarbon") == rank(ph, "eco2ai") for ph in ["train", "infer"]}
    elif not cc.empty:
        S["crosscheck_errors"] = cc[cc.phase == "error"]["emissions_kg"].tolist()

    # ---- derived values quoted in the report (computed here so every number traces to summary.json)
    D = {"infer_share_at_1e6": {}, "block_duration_s": {}}
    for t in tiers_all:
        d = S["tiers"][t]
        for basis in ["net", "gross"]:
            inf_e = 1e6 * d[f"infer_{basis}_uwh"]["mean"] * 1e-6
            D["infer_share_at_1e6"].setdefault(t, {})[basis] = inf_e / (d[f"train_{basis}_wh"]["mean"] + inf_e)
        dur = inf[inf.tier == t].duration_s
        D["block_duration_s"][t] = {"min": float(dur.min()), "max": float(dur.max())}
    lat = {t: S["tiers"][t]["latency_us"]["mean"] for t in TIERS}
    gro = {t: S["tiers"][t]["infer_gross_uwh"]["mean"] for t in TIERS}
    D["latency_ratio"] = {"mlp/logreg": lat["mlp"] / lat["logreg"], "cnn/mlp": lat["cnn"] / lat["mlp"],
                          "cnn/logreg": lat["cnn"] / lat["logreg"]}
    D["gross_infer_ratio"] = {"mlp/logreg": gro["mlp"] / gro["logreg"], "cnn/mlp": gro["cnn"] / gro["mlp"],
                              "cnn/logreg": gro["cnn"] / gro["logreg"]}
    D["macs_ratio"] = {"mlp/logreg": facts["mlp"]["macs"] / facts["logreg"]["macs"],
                       "cnn/mlp": facts["cnn"]["macs"] / facts["mlp"]["macs"]}
    D["gross_train_ratio"] = {"cnn/mlp": S["tiers"]["cnn"]["train_gross_wh"]["mean"] / S["tiers"]["mlp"]["train_gross_wh"]["mean"],
                              "mlp/logreg": S["tiers"]["mlp"]["train_gross_wh"]["mean"] / S["tiers"]["logreg"]["train_gross_wh"]["mean"]}
    if "crosscheck" in S:
        rs = [v["ratio"] for t in S["crosscheck"] for v in S["crosscheck"][t].values()]
        D["eco2ai_ratio_range"] = [min(rs), max(rs)]
    D["etotal_wh"] = {t: {f"{n:.0e}": {b: S["tiers"][t][f"train_{b}_wh"]["mean"] + n * S["tiers"][t][f"infer_{b}_uwh"]["mean"] * 1e-6
                                        for b in ["net", "gross"]} for n in [1e3, 1e6, 1e9]} for t in TIERS}
    T_ = S["tiers"]
    if "sk_logreg" in T_:
        D["sk_vs_torch"] = {
            "train_time_sk/logreg": T_["sk_logreg"]["train_time_s"]["mean"] / T_["logreg"]["train_time_s"]["mean"],
            "train_gross_sk/mlp": T_["sk_logreg"]["train_gross_wh"]["mean"] / T_["mlp"]["train_gross_wh"]["mean"],
            "infer_gross_sk/logreg": T_["sk_logreg"]["infer_gross_uwh"]["mean"] / T_["logreg"]["infer_gross_uwh"]["mean"]}
    D["acc_gain_pts"] = {"mlp-logreg": (T_["mlp"]["test_acc"]["mean"] - T_["logreg"]["test_acc"]["mean"]) * 100,
                         "cnn-mlp": (T_["cnn"]["test_acc"]["mean"] - T_["mlp"]["test_acc"]["mean"]) * 100,
                         "cnn-logreg": (T_["cnn"]["test_acc"]["mean"] - T_["logreg"]["test_acc"]["mean"]) * 100}
    D["acc_minus_f1_pts"] = {t: (T_[t]["test_acc"]["mean"] - T_[t]["test_f1"]["mean"]) * 100 for t in TIERS}
    D["cnn_net_over_gross_infer"] = T_["cnn"]["infer_net_uwh"]["mean"] / T_["cnn"]["infer_gross_uwh"]["mean"]
    if "crosscheck" in S:
        D["codecarbon_over_eco2ai_range"] = [1 / D["eco2ai_ratio_range"][1], 1 / D["eco2ai_ratio_range"][0]]
    if not tune.empty:
        D["tuning_over_cnn_train_gross"] = float(tune.energy_kwh.sum() * 1e3) / T_["cnn"]["train_gross_wh"]["mean"]
    S["derived"] = D

    if not tune.empty:
        S["tuning_total_wh"] = float(tune.energy_kwh.sum() * 1e3)
        S["tuning"] = tune.assign(E_wh=tune.energy_kwh * 1e3)[["tier", "lr", "val_acc", "E_wh"]].to_dict("records")

    # ===================================================== figures
    T = TIERS
    x = np.arange(len(T))

    # F1: training energy
    fig, ax = plt.subplots(figsize=(5.6, 3.3))
    for i, t in enumerate(T):
        d = S["tiers"][t]["train_net_wh"]
        ax.bar(i, d["mean"], width=0.55, color=COLOR[t], yerr=d["ci95"], capsize=4,
               error_kw={"elinewidth": 1, "ecolor": INK2})
        ax.scatter(np.full(d["n"], i) + RNG.uniform(-0.12, 0.12, d["n"]), d["values"], s=14,
                   color="white", edgecolor=INK, linewidth=0.7, zorder=3)
        ax.annotate(f"{d['mean']:.3g} Wh", (i, d["mean"] + (d["ci95"] or 0)), textcoords="offset points",
                    xytext=(0, 5), ha="center", fontsize=9, color=INK)
    ax.set_xticks(x, [LABEL[t] for t in T])
    ax.set_ylabel("Training energy, net of idle (Wh)")
    ax.margins(y=0.15)
    save(fig, figdir, "fig_train_energy")

    # F2: per-call inference energy, gross vs net
    fig, ax = plt.subplots(figsize=(5.6, 3.3))
    w = 0.36
    for i, t in enumerate(T):
        for j, (basis, alpha, hatch) in enumerate([("gross", 0.45, "//"), ("net", 1.0, None)]):
            d = S["tiers"][t][f"infer_{basis}_uwh"]
            ax.bar(i + (j - 0.5) * w, d["mean"], width=w * 0.92, color=COLOR[t], alpha=alpha, hatch=hatch,
                   edgecolor="white", linewidth=0, yerr=d["ci95"], capsize=3,
                   error_kw={"elinewidth": 1, "ecolor": INK2})
            ax.annotate(f"{d['mean']:.3g}", (i + (j - 0.5) * w, d["mean"]), textcoords="offset points",
                        xytext=(0, 4), ha="center", fontsize=8, color=INK)
    ax.set_yscale("log")
    ax.set_xticks(x, [LABEL[t] for t in T])
    ax.set_ylabel(r"Energy per prediction ($\mu$Wh)")
    from matplotlib.patches import Patch
    ax.legend(handles=[Patch(facecolor="#9a9a9a", alpha=0.45, hatch="//", label="gross (whole machine)"),
                       Patch(facecolor="#555555", label="net of idle baseline")], loc="upper left", fontsize=8)
    ax.margins(y=0.2)
    save(fig, figdir, "fig_infer_energy")

    # F3: cumulative energy vs N with crossovers and bootstrap bands
    fig, ax = plt.subplots(figsize=(6.2, 4.0))
    Ng = np.logspace(0, 10, 300)
    for t in T:
        tv = tr[tr.tier == t].E_net_wh.values
        iv = inf[inf.tier == t].e_net_uwh.values * 1e-6
        mean = tv.mean() + Ng * iv.mean()
        bs = np.array([RNG.choice(tv, len(tv)).mean() + Ng * RNG.choice(iv, len(iv)).mean() for _ in range(400)])
        lo, hi = np.percentile(bs, 2.5, 0), np.percentile(bs, 97.5, 0)
        lo = np.where(lo > 0, lo, np.nan)  # a log axis cannot show a band that crosses zero
        ax.fill_between(Ng, lo, hi, color=COLOR[t], alpha=0.15, linewidth=0)
        ax.plot(Ng, mean, color=COLOR[t], lw=2, label=LABEL[t])
    for key, c in S["crossover"]["net"].items():
        if c["case"] == "crossover" and 1 <= c["n_star"] <= 1e10:
            n = c["n_star"]
            e = S["tiers"][c["A"]]["train_net_wh"]["mean"] + n * S["tiers"][c["A"]]["infer_net_uwh"]["mean"] * 1e-6
            ax.plot(n, e, "o", ms=8, mfc="white", mec=INK, mew=1.2, zorder=5)
            ax.annotate(f"$N^*_{{\\mathrm{{{SHORT[c['A']]},{SHORT[c['B']]}}}}}\\approx {n / 10 ** int(np.floor(np.log10(n))):.1f}\\times10^{{{int(np.floor(np.log10(n)))}}}$", (n, e),
                        textcoords="offset points", xytext=(-8, 10), ha="right", fontsize=8.5, color=INK)
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel("Inference volume $N$ (number of predictions)")
    ax.set_ylabel(r"Cumulative energy $E_{\mathrm{total}}(N)$ (Wh)")
    ax.legend(loc="upper left")
    ylo = ax.get_ylim()[0]
    for nn, lab in [(1e3, "pilot"), (1e6, "small service"), (1e9, "large service")]:
        ax.axvline(nn, color="#c9c8c3", lw=0.9, ls=":", zorder=0)
        ax.text(nn * 1.4, ylo * 3, lab, rotation=90, va="bottom", ha="left", fontsize=7.5, color=INK2)
    save(fig, figdir, "fig_cumulative_energy")

    # F4: accuracy vs cumulative energy at three volumes
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.7), sharey=True)
    for ax, N in zip(axes, [1e3, 1e6, 1e9]):
        for t in T:
            d = S["tiers"][t]
            e = d["train_net_wh"]["mean"] + N * d["infer_net_uwh"]["mean"] * 1e-6
            ax.errorbar(e, d["test_acc"]["mean"] * 100, yerr=d["test_acc"]["ci95"] * 100, fmt="o", ms=8,
                        color=COLOR[t], mec="white", mew=1.2, capsize=3)
            ax.annotate(SHORT[t], (e, d["test_acc"]["mean"] * 100), textcoords="offset points", xytext=(6, -3),
                        fontsize=8, color=INK)
        ax.set_xscale("log")
        ax.set_title(f"$N = 10^{{{int(np.log10(N))}}}$", fontsize=10)
        ax.set_xlabel("Cumulative energy (Wh)")
        ax.margins(x=0.35)
    axes[0].set_ylabel("Test accuracy (%)")
    fig.tight_layout()
    save(fig, figdir, "fig_accuracy_energy")

    # F5: decision map
    acc_lo = min(accs.values()) - 0.02
    acc_hi = max(accs.values()) + 0.005
    Nm = np.logspace(0, 10, 400)
    Am = np.linspace(acc_lo, acc_hi, 300)
    idx = {None: 0, "logreg": 1, "mlp": 2, "cnn": 3}
    Z = np.array([[idx[recommend(n, a)[0]] for n in Nm] for a in Am])
    cmap = ListedColormap(["#efeeeb", COLOR["logreg"], COLOR["mlp"], COLOR["cnn"]])
    fig, ax = plt.subplots(figsize=(6.2, 3.6))
    ax.pcolormesh(Nm, Am * 100, Z, cmap=cmap, vmin=0, vmax=3, shading="auto", alpha=0.85)
    ax.set_xscale("log")
    ax.grid(False)
    for t in T:
        ax.axhline(accs[t] * 100, color="white", lw=1, ls="--")
    present = sorted(set(Z.flatten()))
    names = {0: "no tier meets $a_{\\min}$", 1: LABEL["logreg"], 2: LABEL["mlp"], 3: LABEL["cnn"]}
    ax.legend(handles=[Patch(facecolor=cmap(k), label=names[k]) for k in present], loc="upper center",
              bbox_to_anchor=(0.5, -0.2), ncol=len(present), fontsize=8)
    ax.set_xlabel("Expected inference volume $N$")
    ax.set_ylabel("Minimum accuracy $a_{\\min}$ (%)")
    save(fig, figdir, "fig_decision_map")

    # F6: learning curves
    fig, ax = plt.subplots(figsize=(5.6, 3.2))
    for t in T:
        g = ep[ep.tier == t].groupby("epoch").val_acc
        m, s = g.mean() * 100, g.std().fillna(0) * 100
        ax.plot(m.index, m.values, color=COLOR[t], lw=2, marker="o", ms=4, label=LABEL[t])
        ax.fill_between(m.index, m - s, m + s, color=COLOR[t], alpha=0.15, linewidth=0)
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Validation accuracy (%)")
    ax.legend(loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=3, fontsize=8.5)
    save(fig, figdir, "fig_learning_curves")

    # F7: where the training energy goes (CPU vs RAM)
    fig, ax = plt.subplots(figsize=(5.6, 2.6))
    for i, t in enumerate(T):
        cpu, ram = S["tiers"][t]["train_cpu_wh"]["mean"], S["tiers"][t]["train_ram_wh"]["mean"]
        tot = cpu + ram
        ax.barh(i, cpu / tot * 100, color=COLOR[t], height=0.55)
        ax.barh(i, ram / tot * 100, left=cpu / tot * 100, color=COLOR[t], alpha=0.35, height=0.55,
                edgecolor="white", linewidth=2)
        ax.text(cpu / tot * 50, i, f"CPU {cpu / tot * 100:.0f}%", ha="center", va="center", fontsize=8,
                color="white")
        ax.text(cpu / tot * 100 + ram / tot * 50, i, f"RAM {ram / tot * 100:.0f}%", ha="center", va="center",
                fontsize=8, color=INK)
    ax.set_yticks(range(len(T)), [LABEL[t] for t in T])
    ax.set_xlim(0, 100)
    ax.set_xlabel("Share of training energy (%)")
    ax.grid(False)
    save(fig, figdir, "fig_energy_breakdown")

    # F8: bootstrap distributions of N*
    xs = [(k, c) for k, c in S["crossover"]["net"].items() if c["p_crossover"] > 0.05]
    if xs:
        fig, axes = plt.subplots(1, len(xs), figsize=(2.6 * len(xs) + 0.6, 2.6), squeeze=False)
        for ax, (k, c) in zip(axes[0], xs):
            A, B = c["A"], c["B"]
            tA, tB = tr[tr.tier == A].E_net_wh.values, tr[tr.tier == B].E_net_wh.values
            iA, iB = inf[inf.tier == A].e_net_uwh.values * 1e-6, inf[inf.tier == B].e_net_uwh.values * 1e-6
            vals = []
            for _ in range(4000):
                cs, nb = classify(RNG.choice(tA, len(tA)).mean(), RNG.choice(iA, len(iA)).mean(),
                                  RNG.choice(tB, len(tB)).mean(), RNG.choice(iB, len(iB)).mean())
                if cs == "crossover":
                    vals.append(nb)
            vals = np.log10(vals)
            ax.hist(vals, bins=40, color=COLOR[B], alpha=0.8, edgecolor="white", linewidth=0.5)
            if c["n_star"]:
                ax.axvline(np.log10(c["n_star"]), color=INK, lw=1.2)
            ax.set_title(f"{SHORT[A]} vs {SHORT[B]}  (p = {c['p_crossover']:.2f})", fontsize=9)
            ax.set_xlabel(r"$\log_{10} N^*$")
            ax.set_yticks([])
        save(fig, figdir, "fig_bootstrap_nstar")

    # F9: per-call energy and latency against arithmetic cost
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.9))
    for t in T:
        d = S["tiers"][t]
        axes[0].scatter(d["macs"], d["infer_net_uwh"]["mean"], s=60, color=COLOR[t], edgecolor="white", zorder=3)
        axes[0].scatter(d["macs"], d["infer_gross_uwh"]["mean"], s=60, facecolor="white", edgecolor=COLOR[t],
                        linewidth=1.4, zorder=3)
        axes[1].scatter(d["macs"], d["latency_us"]["mean"], s=60, color=COLOR[t], edgecolor="white", zorder=3)
        for ax, v in [(axes[0], d["infer_net_uwh"]["mean"]), (axes[1], d["latency_us"]["mean"])]:
            ax.annotate(SHORT[t], (d["macs"], v), textcoords="offset points", xytext=(7, -3), fontsize=8)
    for ax in axes:
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.set_xlabel("MACs per prediction")
        ax.margins(0.3)
    axes[0].set_ylabel(r"Energy per call ($\mu$Wh)")
    axes[0].legend(handles=[plt.Line2D([], [], marker="o", ls="", color="#555", label="net"),
                            plt.Line2D([], [], marker="o", ls="", mfc="white", mec="#555", label="gross")],
                   fontsize=8, loc="upper left")
    axes[1].set_ylabel(r"Latency per call ($\mu$s)")
    fig.tight_layout()
    save(fig, figdir, "fig_cost_vs_macs")

    # F10: confusion matrices
    classes = ["T-shirt", "Trouser", "Pullover", "Dress", "Coat", "Sandal", "Shirt", "Sneaker", "Bag", "Boot"]
    try:
        from torchvision import datasets
        y_test = datasets.FashionMNIST(env["args"]["data"], train=False, download=False).targets.numpy()
    except Exception:
        y_test = None
    if y_test is not None and all(os.path.exists(os.path.join(run_dir, f"test_preds_{t}.npy")) for t in T):
        from sklearn.metrics import confusion_matrix
        fig, axes = plt.subplots(1, 3, figsize=(7.4, 2.9))
        cm_seq = ListedColormap(plt.get_cmap("Blues")(np.linspace(0.02, 0.95, 256)))
        S["per_class_acc"] = {}
        for ax, t in zip(axes, T):
            p = np.load(os.path.join(run_dir, f"test_preds_{t}.npy"))
            cm = confusion_matrix(y_test, p, normalize="true")
            S["per_class_acc"][t] = dict(zip(classes, np.diag(cm).round(4).tolist()))
            ax.imshow(cm, cmap=cm_seq, vmin=0, vmax=1)
            ax.set_title(LABEL[t], fontsize=9)
            ax.set_xticks(range(10), classes, rotation=90, fontsize=6)
            ax.set_yticks(range(10), classes if t == "logreg" else [""] * 10, fontsize=6)
            ax.grid(False)
            for s in ax.spines.values():
                s.set_visible(False)
        axes[0].set_ylabel("True class", fontsize=9)
        fig.supxlabel("Predicted class", fontsize=9, y=0.0)
        fig.tight_layout()
        save(fig, figdir, "fig_confusion")

    # F11: tracker cross-check
    if "crosscheck" in S:
        fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.8))
        for ax, phase, unit in [(axes[0], "train", "Training energy (Wh)"),
                                (axes[1], "infer", r"Energy per call ($\mu$Wh)")]:
            ts = [t for t in T if phase in S["crosscheck"].get(t, {})]
            for i, t in enumerate(ts):
                v = S["crosscheck"][t][phase]
                ax.bar(i - 0.19, v["codecarbon"], 0.36, color=COLOR[t])
                ax.bar(i + 0.19, v["eco2ai"], 0.36, color=COLOR[t], alpha=0.4, hatch="..", edgecolor="white")
            ax.set_xticks(range(len(ts)), [SHORT[t] for t in ts])
            ax.set_yscale("log")
            ax.set_ylabel(unit)
        axes[1].legend(handles=[Patch(facecolor="#555", label="CodeCarbon"),
                                Patch(facecolor="#555", alpha=0.4, hatch="..", label="eco2AI")], fontsize=8)
        fig.tight_layout()
        save(fig, figdir, "fig_crosscheck")

    # F12: measurement stability - every training run and block in the order taken
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.5))
    axes[0].plot(idle.index + 1, idle.power_w, marker="o", color=INK2, lw=1.2)
    axes[0].set_title("Idle power (W)", fontsize=9)
    axes[0].ticklabel_format(axis="y", useOffset=False)
    axes[0].set_xlabel("Baseline no.")
    for t in T:
        a = tr[tr.tier == t]
        b = inf[inf.tier == t]
        axes[1].plot(a["round"] + 1, a.E_net_wh / a.E_net_wh.mean(), marker="o", ms=4, color=COLOR[t],
                     label=SHORT[t])
        axes[2].plot(b["round"] + 1, b.e_net_uwh / b.e_net_uwh.mean(), marker="o", ms=4, color=COLOR[t])
    axes[1].set_title("Training energy / mean", fontsize=9)
    axes[2].set_title("Per-call energy / mean", fontsize=9)
    axes[0].set_xticks(range(1, len(idle) + 1))
    for ax in axes[1:]:
        ax.set_xticks(range(1, int(tr["round"].max()) + 2))
        ax.set_xlabel("Round")
        ax.axhline(1, color=INK2, lw=0.8)
    axes[1].legend(fontsize=7)
    fig.tight_layout()
    save(fig, figdir, "fig_stability")

    # ===================================================== tables
    e = env
    write_table(tabdir, "tab_environment", "Hardware and software used for all measurements", "tab:env",
                "p{4.2cm}p{9cm}", ["Item", "Value"], [
                    ["Machine", str(e.get("model") or e.get("machine"))],
                    ["Processor", str(e.get("cpu"))],
                    ["Memory", f"{e.get('ram_gb')} GB"],
                    ["Operating system", str(e.get("macos") and f"macOS {e['macos']}" or e.get("os"))],
                    ["Python / PyTorch", f"{e['python']} / {e['torch']}"],
                    ["scikit-learn / NumPy", f"{e['sklearn']} / {e['numpy']}"],
                    ["CodeCarbon / eco2AI", f"{e.get('codecarbon')} / {e.get('eco2ai')}"],
                    ["PyTorch threads", str(e["torch_threads"])],
                    ["CodeCarbon CPU method", S["tracker_method"].replace("_", "\\_")],
                    ["Grid intensity used", f"{intensity * 1000:.0f} g CO$_2$e/kWh (CodeCarbon, India)"],
                ])

    rows = []
    for t in tiers_all:
        d = S["tiers"][t]
        rows.append([LABEL[t], f"{d['train_time_s']['mean']:.1f}",
                     f"{fmt(d['train_gross_wh']['mean'])}",
                     f"{fmt(d['train_net_wh']['mean'])} $\\pm$ {fmt(d['train_net_wh']['ci95'], 2)}",
                     f"{d['train_net_wh']['cv'] * 100:.1f}", f"{fmt(d['train_co2_g']['mean'])}"])
    write_table(tabdir, "tab_training", f"Training energy per run (mean of $R={S['tiers']['logreg']['train_net_wh']['n']}$ runs, $\\pm$ 95\\% CI)",
                "tab:train", "lrrrrr",
                ["Tier", "Time (s)", "$E_{\\text{train}}$ gross (Wh)", "$E_{\\text{train}}$ net (Wh)", "CV (\\%)",
                 "CO$_2$e (g)"], rows)

    rows = []
    for t in tiers_all:
        d = S["tiers"][t]
        rows.append([LABEL[t], f"{d['calls_per_block']:,}".replace(",", "{,}"), f"{d['latency_us']['mean']:.1f}",
                     fmt(d["infer_gross_uwh"]["mean"]),
                     f"{fmt(d['infer_net_uwh']['mean'])} $\\pm$ {fmt(d['infer_net_uwh']['ci95'], 2)}",
                     f"{d['infer_net_uwh']['cv'] * 100:.1f}"])
    write_table(tabdir, "tab_inference", "Per-prediction energy, single-sample inference (mean of blocks, $\\pm$ 95\\% CI)",
                "tab:infer", "lrrrrr",
                ["Tier", "Calls/block $M$", "Latency ($\\mu$s)", "$E_{\\text{infer}}$ gross ($\\mu$Wh)",
                 "$E_{\\text{infer}}$ net ($\\mu$Wh)", "CV (\\%)"], rows)

    rows = []
    for t in tiers_all:
        d = S["tiers"][t]
        rows.append([LABEL[t], f"{d['params']:,}".replace(",", "{,}"), f"{d['macs']:,}".replace(",", "{,}"),
                     f"{d['test_acc']['mean'] * 100:.2f} $\\pm$ {d['test_acc']['ci95'] * 100:.2f}",
                     f"{d['test_f1']['mean'] * 100:.2f}"])
    write_table(tabdir, "tab_accuracy", "Model size and test-set performance", "tab:acc", "lrrrr",
                ["Tier", "Parameters", "MACs/prediction", "Accuracy (\\%)", "Macro F1 (\\%)"], rows)

    rows = []
    for key, c in S["crossover"]["net"].items():
        g = S["crossover"]["gross"][key]
        interval = (f"[{fmt_n(c['boot_lo'])}, {fmt_n(c['boot_hi'])}]" if c["boot_lo"] else "--")
        rows.append([f"{SHORT[c['A']]} vs {SHORT[c['B']]}", c["case"], fmt_n(c["n_star"]) if c["n_star"] else "--",
                     interval, f"{c['p_crossover']:.2f}", fmt_n(g["n_star"]) if g["n_star"] else g["case"],
                     c["winner"]])
    write_table(tabdir, "tab_crossover", "Pairwise crossover volumes (net energy; bootstrap with 10{,}000 resamples)",
                "tab:crossover", "llrlrlp{3.3cm}",
                ["Pair", "Case", "$N^*$", "95\\% interval", "$P(\\text{cross})$", "$N^*$ gross", "Lower energy"],
                rows)

    hdr = ["$a_{\\min}$"] + [f"$N=10^{{{int(np.log10(v))}}}$" for v in volumes]
    rows = [[f"{r['amin'] * 100:.1f}\\%" if r["amin"] else "none"] +
            [SHORT[v] if v else "--" for v in r["rec"].values()] for r in S["decision_table"]]
    write_table(tabdir, "tab_decision", "Recommended tier for a given volume and accuracy floor (Eqn.~3.3)",
                "tab:decision", "l" + "c" * len(volumes), hdr, rows,
                note="``--'' means no studied tier reaches the accuracy floor.")

    if "crosscheck" in S:
        rows = []
        for t in T:
            for ph, unit in [("train", "Wh"), ("infer", "$\\mu$Wh/call")]:
                v = S["crosscheck"].get(t, {}).get(ph)
                if v:
                    rows.append([LABEL[t], "training" if ph == "train" else "inference", unit,
                                 fmt(v["codecarbon"]), fmt(v["eco2ai"]), fmt(v["ratio"])])
        write_table(tabdir, "tab_crosscheck", "CodeCarbon and eco2AI on the same work", "tab:crosscheck",
                    "lllrrr", ["Tier", "Phase", "Unit", "CodeCarbon", "eco2AI", "Ratio"], rows)

    rows = [[f"{SHORT[S['crossover']['net'][k]['A']]} vs {SHORT[S['crossover']['net'][k]['B']]}"] +
            [fmt_n(v) for v in d.values()] for k, d in S["co2_sensitivity"].items()]
    if rows:
        write_table(tabdir, "tab_co2_sensitivity", "Emissions crossover when training runs on a cleaner grid (Eqn.~3.2)",
                    "tab:co2sens", "lrrrr",
                    ["Pair", "$I_{\\text{train}}/I_{\\text{infer}}=1$", "0.5", "0.25", "0.1"], rows)

    if not tune.empty:
        rows = [[LABEL[r["tier"]], f"{r['lr']:g}", f"{r['val_acc'] * 100:.2f}", fmt(r["E_wh"])] for r in S["tuning"]]
        write_table(tabdir, "tab_tuning", "Learning-rate sweep, logged separately from $E_{\\text{train}}$",
                    "tab:tuning", "lrrr", ["Tier", "Learning rate", "Val. acc. (\\%)", "Energy (Wh)"], rows)

    with open(os.path.join(out, "summary.json"), "w") as f:
        json.dump(S, f, indent=2, default=str)

    # ---- console digest
    print(f"\nTracker CPU method: {S['tracker_method']}")
    print(f"Idle power: {S['idle_power_w']['mean']:.2f} W  (cv {S['idle_power_w']['cv'] * 100:.1f}%)")
    for t in tiers_all:
        d = S["tiers"][t]
        print(f"{t:10s} train {d['train_net_wh']['mean']:.4g} Wh (cv {d['train_net_wh']['cv'] * 100:.0f}%), "
              f"infer {d['infer_net_uwh']['mean']:.4g} uWh/call net, {d['infer_gross_uwh']['mean']:.4g} gross, "
              f"acc {d['test_acc']['mean'] * 100:.2f}%")
    for k, c in S["crossover"]["net"].items():
        print(f"{k:12s} {c['case']:10s} N*={c['n_star']}  p={c['p_crossover']:.2f}  "
              f"[{c['boot_lo']}, {c['boot_hi']}]  numerical={S['crossover_numerical_net'][k]}")
    if "crosscheck_rank_agree" in S:
        print("eco2AI rank agreement:", S["crosscheck_rank_agree"])
    print(f"\nFigures: {figdir}\nTables:  {tabdir}")


if __name__ == "__main__":
    main(sys.argv[1])
