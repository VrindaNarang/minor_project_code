"""Extended study: second dataset, four more tiers, batched inference, phase log.

Everything the original three-tier study used (data split, LogReg/MLP/SmallCNN,
10 epochs, Adam lr 1e-3, batch 64) is reused from common.py unchanged. This
module only adds:

  * the SMS Spam Collection (TF-IDF features for the vector models, token ids
    for a small text CNN),
  * four further tiers on both datasets: an int8-quantised CNN (post-training
    static quantisation of the trained CNN), k-nearest neighbours, an RBF-kernel
    SVM and a random forest,
  * predictors for single-sample and batched inference that start from the raw
    input (a normalised image, or a raw text message),
  * a phase log with wall-clock start/end times, so that power sampled by
    `powermetrics` in a separate process can be attributed to each phase.
"""
import copy
import csv
import os
import re
import time
from collections import Counter

import numpy as np
import torch
import torch.nn as nn

from common import build_model

EXT_TIERS = ["logreg", "mlp", "cnn", "cnn_int8", "knn", "svm", "rf"]
TORCH_TIERS = ["logreg", "mlp", "cnn"]
SK_TIERS = ["knn", "svm", "rf"]
EXT_LABELS = {
    "logreg": "Logistic regression", "mlp": "MLP", "cnn": "CNN", "cnn_int8": "CNN (int8)",
    "knn": "k-NN", "svm": "RBF SVM", "rf": "Random forest",
}
SVM_TRAIN_LIMIT = 20000   # kernel SVM training grows roughly quadratically; see Chapter 3
SMS_MAX_LEN = 64
SMS_TFIDF = dict(lowercase=True, ngram_range=(1, 2), min_df=2, sublinear_tf=True, max_features=5000)


# ----------------------------------------------------------------------------- SMS data
def load_sms(data_dir, seed=0):
    """SMS Spam Collection: stratified 70 / 10 / 20 train / val / test split, fixed seed."""
    from sklearn.model_selection import train_test_split

    path = os.path.join(data_dir, "sms", "SMSSpamCollection")
    texts, labels = [], []
    with open(path, encoding="utf-8") as f:
        for line in f:
            lab, txt = line.rstrip("\n").split("\t", 1)
            texts.append(txt)
            labels.append(1 if lab == "spam" else 0)
    idx = np.arange(len(texts))
    y = np.array(labels)
    rest, test = train_test_split(idx, test_size=0.2, stratify=y, random_state=seed)
    train, val = train_test_split(rest, test_size=0.125, stratify=y[rest], random_state=seed)
    pick = lambda ii: [texts[i] for i in ii]
    return {"t_train": pick(train), "y_train": y[train], "t_val": pick(val), "y_val": y[val],
            "t_test": pick(test), "y_test": y[test],
            "split_indices": {"train": train.tolist(), "val": val.tolist(), "test": test.tolist()}}


_TOKEN = re.compile(r"[a-z0-9']+")


def tokenize(s):
    return _TOKEN.findall(s.lower())


class Vocab:
    """Word-to-id map built from the training messages (ids 0 = pad, 1 = unknown)."""

    def __init__(self, texts, min_count=2):
        c = Counter(w for t in texts for w in tokenize(t))
        self.itos = ["<pad>", "<unk>"] + sorted(w for w, n in c.items() if n >= min_count)
        self.stoi = {w: i for i, w in enumerate(self.itos)}

    def encode(self, texts, max_len=SMS_MAX_LEN):
        out = torch.zeros(len(texts), max_len, dtype=torch.long)
        for r, t in enumerate(texts):
            ids = [self.stoi.get(w, 1) for w in tokenize(t)][:max_len]
            if ids:
                out[r, :len(ids)] = torch.tensor(ids)
        return out


class TextCNN(nn.Module):
    """Embedding 64 -> Conv1d(64, 128, 5) -> ReLU -> global max pool -> Linear(128, 2)."""

    def __init__(self, vocab_size, emb=64, ch=128, k=5, n_out=2):
        super().__init__()
        self.emb = nn.Embedding(vocab_size, emb, padding_idx=0)
        self.conv = nn.Conv1d(emb, ch, k, padding=k // 2)
        self.fc = nn.Linear(ch, n_out)

    def forward(self, x):
        h = torch.relu(self.conv(self.emb(x).transpose(1, 2)))
        return self.fc(h.amax(2))


class VecLogReg(nn.Module):
    def __init__(self, d, n_out=2):
        super().__init__()
        self.fc = nn.Linear(d, n_out)

    def forward(self, x):
        return self.fc(x)


class VecMLP(nn.Module):
    def __init__(self, d, hidden=128, n_out=2):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(d, hidden), nn.ReLU(), nn.Linear(hidden, n_out))

    def forward(self, x):
        return self.net(x)


def sms_macs(tier, d_tfidf, vocab_size=None):
    """Multiply-accumulates per message for the model part (feature extraction excluded)."""
    if tier == "logreg":
        return d_tfidf * 2
    if tier == "mlp":
        return d_tfidf * 128 + 128 * 2
    if tier in ("cnn", "cnn_int8"):
        return SMS_MAX_LEN * 128 * 64 * 5 + 128 * 2
    return None


# ------------------------------------------------------------------------ quantisation
def quantize_int8(model, calib_batches, example):
    """Post-training static int8 quantisation (FX graph mode, qnnpack back end)."""
    from torch.ao.quantization import get_default_qconfig_mapping
    from torch.ao.quantization.quantize_fx import convert_fx, prepare_fx

    torch.backends.quantized.engine = "qnnpack"
    m = copy.deepcopy(model).eval()
    prepared = prepare_fx(m, get_default_qconfig_mapping("qnnpack"), example_inputs=(example,))
    with torch.inference_mode():
        for xb in calib_batches:
            prepared(xb)
    return convert_fx(prepared)


# ------------------------------------------------------------------------ sklearn tiers
def build_sklearn(tier, seed, sparse=False):
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.neighbors import KNeighborsClassifier
    from sklearn.svm import SVC

    if tier == "knn":
        return KNeighborsClassifier(n_neighbors=5, metric="cosine" if sparse else "minkowski",
                                    algorithm="brute")
    if tier == "svm":
        return SVC(kernel="rbf", C=1.0, gamma="scale", random_state=seed)
    if tier == "rf":
        return RandomForestClassifier(n_estimators=100, n_jobs=4, random_state=seed)
    raise ValueError(tier)


# ------------------------------------------------------------------------------ phase log
class PhaseLog:
    """Append one row per measured phase: wall-clock start/end (Unix time) and labels.

    `powermetrics` runs in a separate (root) process and writes timestamped
    samples; parse_powermetrics.py integrates its power over these intervals.
    """

    FIELDS = ["phase_id", "dataset", "round", "tier", "kind", "t_start", "t_end", "calls", "batch"]

    def __init__(self, path):
        self.path = path
        self.n = 0
        if not os.path.exists(path):
            with open(path, "w", newline="") as f:
                csv.writer(f).writerow(self.FIELDS)

    def phase(self, dataset, rnd, tier, kind, calls=None, batch=None):
        log = self

        class _P:
            def __enter__(self):
                self.t0 = time.time()
                return self

            def __exit__(self, *exc):
                t1 = time.time()
                log.n += 1
                with open(log.path, "a", newline="") as f:
                    csv.writer(f).writerow([log.n, dataset, rnd, tier, kind, f"{self.t0:.3f}", f"{t1:.3f}",
                                            calls, batch])
                self.phase_id = log.n
                return False
        return _P()


class Both:
    """Enter a CodeCarbon tracker and a phase-log interval together (phase innermost)."""

    def __init__(self, tracker, phase):
        self.tracker, self.phase = tracker, phase

    def __enter__(self):
        self.tracker.__enter__()
        self.phase.__enter__()
        return self

    def __exit__(self, *exc):
        self.phase.__exit__(*exc)
        self.tracker.__exit__(*exc)
        self.result = self.tracker.result
        self.method = self.tracker.method
        self.phase_id = self.phase.phase_id
        return False


__all__ = ["EXT_TIERS", "TORCH_TIERS", "SK_TIERS", "EXT_LABELS", "SVM_TRAIN_LIMIT", "SMS_TFIDF",
           "load_sms", "Vocab", "TextCNN", "VecLogReg", "VecMLP", "sms_macs", "quantize_int8",
           "build_sklearn", "PhaseLog", "Both", "build_model"]
