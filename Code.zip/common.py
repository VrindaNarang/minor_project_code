"""Shared pieces: data loading, the three model tiers, and the energy trackers."""
import json
import os
import platform
import random
import subprocess
import sys
import time
import warnings

import numpy as np
import torch
import torch.nn as nn

TIERS = ["logreg", "mlp", "cnn"]
TIER_LABELS = {
    "logreg": "Logistic regression",
    "mlp": "MLP",
    "cnn": "Small CNN",
    "sk_logreg": "scikit-learn LR (reference)",
}


# --------------------------------------------------------------------------- data
def load_fashion_mnist(data_dir, val_size=6000, seed=0):
    """Return normalised tensors for train / val / test (N, 1, 28, 28) and labels.

    The 60k official training set is split 54k / 6k with a fixed seed; the
    official 10k test set is only used for final evaluation.
    """
    from torchvision import datasets

    tr = datasets.FashionMNIST(data_dir, train=True, download=True)
    te = datasets.FashionMNIST(data_dir, train=False, download=True)
    x_all = tr.data.float().div(255.0).unsqueeze(1)
    y_all = tr.targets.clone()
    x_test = te.data.float().div(255.0).unsqueeze(1)
    y_test = te.targets.clone()

    g = torch.Generator().manual_seed(seed)
    perm = torch.randperm(len(x_all), generator=g)
    val_idx, tr_idx = perm[:val_size], perm[val_size:]
    x_tr, y_tr = x_all[tr_idx], y_all[tr_idx]
    x_val, y_val = x_all[val_idx], y_all[val_idx]

    mean, std = x_tr.mean().item(), x_tr.std().item()
    norm = lambda x: (x - mean) / std
    return {
        "x_train": norm(x_tr), "y_train": y_tr,
        "x_val": norm(x_val), "y_val": y_val,
        "x_test": norm(x_test), "y_test": y_test,
        "mean": mean, "std": std,
        "split_indices": {"train": tr_idx.tolist(), "val": val_idx.tolist()},
    }


# ------------------------------------------------------------------------- models
class LogReg(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc = nn.Linear(784, 10)

    def forward(self, x):
        return self.fc(x.flatten(1))


class MLP(nn.Module):
    def __init__(self, hidden=128):
        super().__init__()
        self.net = nn.Sequential(nn.Flatten(), nn.Linear(784, hidden), nn.ReLU(), nn.Linear(hidden, 10))

    def forward(self, x):
        return self.net(x)


class SmallCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(1, 16, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(16, 32, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
        )
        self.fc = nn.Linear(32 * 7 * 7, 10)

    def forward(self, x):
        return self.fc(self.features(x).flatten(1))


def build_model(tier):
    return {"logreg": LogReg, "mlp": MLP, "cnn": SmallCNN}[tier]()


def count_params(model):
    return sum(p.numel() for p in model.parameters())


def count_macs(tier):
    """Multiply-accumulates per single prediction (matches Table 2.1 of the report)."""
    if tier == "logreg":
        return 784 * 10
    if tier == "mlp":
        return 784 * 128 + 128 * 10
    if tier == "cnn":
        conv1 = 28 * 28 * 16 * 9 * 1
        conv2 = 14 * 14 * 32 * 9 * 16
        fc = 1568 * 10
        return conv1 + conv2 + fc
    if tier == "sk_logreg":
        return 784 * 10
    raise ValueError(tier)


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


# ----------------------------------------------------------------------- trackers
class CCTracker:
    """Thin wrapper around CodeCarbon's offline tracker.

    Returns a dict with duration (s), energy (kWh) split by component and
    emissions (kg CO2e). Uses a fixed country so all runs share one grid
    intensity.
    """

    def __init__(self, country="IND", interval=1.0, output_dir="."):
        self.country = country
        self.interval = interval
        self.output_dir = output_dir
        self.method = None

    def __enter__(self):
        from codecarbon import OfflineEmissionsTracker

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            self._t = OfflineEmissionsTracker(
                country_iso_code=self.country,
                measure_power_secs=self.interval,
                save_to_file=False,
                log_level="error",
                tracking_mode="machine",
                output_dir=self.output_dir,
                allow_multiple_runs=True,
            )
            self._t.start()
        self._t0 = time.perf_counter()
        return self

    def __exit__(self, *exc):
        self._t.stop()
        self.wall = time.perf_counter() - self._t0
        d = self._t.final_emissions_data
        self.result = {
            "duration_s": self.wall,
            "energy_kwh": d.energy_consumed,
            "cpu_energy_kwh": d.cpu_energy,
            "ram_energy_kwh": d.ram_energy,
            "gpu_energy_kwh": d.gpu_energy,
            "emissions_kg": d.emissions,
            "cpu_power_w": d.cpu_power,
            "ram_power_w": d.ram_power,
        }
        # How CodeCarbon measured the CPU (RAPL, powermetrics, CPU-load model, constant TDP...)
        hw = self._t._conf.get("hardware") or []
        self.method = "; ".join(str(h) for h in hw)[:300] or "unknown"
        self.result["cpu_model"] = getattr(d, "cpu_model", None)
        return False


class Eco2AITracker:
    """eco2AI tracker used only for the cross-check runs."""

    def __init__(self, out_csv, name):
        self.out_csv = out_csv
        self.name = name
        self.result = None

    def __enter__(self):
        import eco2ai

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            self._t = eco2ai.Tracker(
                project_name="carbon-aware-model-selection",
                experiment_description=self.name,
                file_name=self.out_csv,
                alpha_2_code="IN",
                measure_period=1,
                ignore_warnings=True,
            )
            self._t.start()
        self._t0 = time.perf_counter()
        return self

    def __exit__(self, *exc):
        self._t.stop()
        self.wall = time.perf_counter() - self._t0
        import pandas as pd

        df = pd.read_csv(self.out_csv)
        row = df[df["experiment_description"] == self.name].iloc[-1]
        self.result = {
            "duration_s": self.wall,
            "energy_kwh": float(row["power_consumption(kWh)"]),
            "emissions_kg": float(row["CO2_emissions(kg)"]),
        }
        return False


# -------------------------------------------------------------------- environment
def _cmd(args):
    try:
        return subprocess.check_output(args, stderr=subprocess.DEVNULL, text=True).strip()
    except Exception:
        return None


def describe_environment(n_threads):
    import sklearn
    import torchvision

    info = {
        "os": platform.platform(),
        "machine": platform.machine(),
        "python": sys.version.split()[0],
        "torch": torch.__version__,
        "torchvision": torchvision.__version__,
        "sklearn": sklearn.__version__,
        "numpy": np.__version__,
        "torch_threads": n_threads,
        "logical_cpus": os.cpu_count(),
    }
    try:
        import codecarbon
        info["codecarbon"] = codecarbon.__version__
    except Exception:
        pass
    try:
        import eco2ai  # noqa: F401
        from importlib.metadata import version
        info["eco2ai"] = version("eco2ai")
    except Exception:
        pass
    if platform.system() == "Darwin":
        info["cpu"] = _cmd(["sysctl", "-n", "machdep.cpu.brand_string"])
        mem = _cmd(["sysctl", "-n", "hw.memsize"])
        info["ram_gb"] = round(int(mem) / 2**30, 1) if mem else None
        info["model"] = _cmd(["sysctl", "-n", "hw.model"])
        info["macos"] = _cmd(["sw_vers", "-productVersion"])
        info["power_source"] = _cmd(["pmset", "-g", "batt"])
    else:
        cpu = None
        try:
            with open("/proc/cpuinfo") as f:
                for line in f:
                    if line.startswith("model name"):
                        cpu = line.split(":", 1)[1].strip()
                        break
        except Exception:
            pass
        info["cpu"] = cpu or platform.processor()
        try:
            import psutil
            info["ram_gb"] = round(psutil.virtual_memory().total / 2**30, 1)
        except Exception:
            pass
    return info


def save_json(obj, path):
    with open(path, "w") as f:
        json.dump(obj, f, indent=2, default=str)
