"""Attribute powermetrics samples to the phases logged by run_extended.py.

powermetrics (run as root in a separate terminal) writes one plist per sample,
separated by NUL bytes. Each sample reports, for the interval that ended at its
`timestamp` and lasted `elapsed_ns`, the power of the CPU, GPU and Neural
Engine as read from the SoC's energy counters (mW), the thermal pressure level
and the frequency of each CPU cluster.

For every phase in phases.csv we integrate power over the part of each sample
interval that overlaps the phase:  E = sum_k P_k * overlap_k.

Usage:  python parse_powermetrics.py <run_dir> [--plist path]
Writes: <run_dir>/power_samples.csv and <run_dir>/phase_power.csv
"""
import argparse
import os
import plistlib
from datetime import timezone

import numpy as np
import pandas as pd

PRESSURE = {"Nominal": 0, "Moderate": 1, "Fair": 1, "Heavy": 2, "Serious": 2, "Trapping": 3, "Critical": 3}


def read_samples(path):
    raw = open(path, "rb").read()
    rows, bad = [], 0
    for chunk in raw.split(b"\x00"):
        chunk = chunk.strip()
        if not chunk:
            continue
        try:
            d = plistlib.loads(chunk)
        except Exception:
            bad += 1                     # e.g. the last, half-written sample after Ctrl-C
            continue
        p = d.get("processor", {})
        ts = d["timestamp"]
        if ts.tzinfo is None:
            ts = ts.replace(tzinfo=timezone.utc)
        dt = d.get("elapsed_ns", 0) / 1e9
        t_end = ts.timestamp()
        row = {"t_start": t_end - dt, "t_end": t_end, "elapsed_s": dt,
               "cpu_w": p.get("cpu_power", np.nan) / 1000 if "cpu_power" in p else np.nan,
               "gpu_w": p.get("gpu_power", np.nan) / 1000 if "gpu_power" in p else np.nan,
               "ane_w": p.get("ane_power", np.nan) / 1000 if "ane_power" in p else np.nan,
               "combined_w": p.get("combined_power", np.nan) / 1000 if "combined_power" in p else np.nan,
               "cpu_energy_mj": p.get("cpu_energy", np.nan),
               "thermal_pressure": d.get("thermal_pressure"),
               }
        # Fall back to energy / interval if a power field is missing
        if np.isnan(row["cpu_w"]) and dt > 0 and not np.isnan(row["cpu_energy_mj"]):
            row["cpu_w"] = row["cpu_energy_mj"] / 1000 / dt
        if np.isnan(row["combined_w"]):
            row["combined_w"] = np.nansum([row["cpu_w"], row["gpu_w"], row["ane_w"]])
        for c in p.get("clusters", []) or []:
            name = str(c.get("name", "cluster")).replace("-Cluster", "").replace(" ", "")
            if "freq_hz" in c:
                row[f"freq_{name}_mhz"] = c["freq_hz"] / 1e6
            if "idle_ratio" in c:
                row[f"busy_{name}"] = 1 - c["idle_ratio"]
        rows.append(row)
    df = pd.DataFrame(rows).sort_values("t_end").reset_index(drop=True)
    df["thermal_level"] = df["thermal_pressure"].map(PRESSURE)
    return df, bad


def integrate(samples, phases):
    s0, s1 = samples["t_start"].to_numpy(), samples["t_end"].to_numpy()
    cols = ["cpu_w", "gpu_w", "ane_w", "combined_w"]
    P = samples[cols].to_numpy()
    freq_cols = [c for c in samples.columns if c.startswith("freq_")]
    out = []
    for _, ph in phases.iterrows():
        a, b = ph["t_start"], ph["t_end"]
        ov = np.clip(np.minimum(s1, b) - np.maximum(s0, a), 0, None)
        covered = ov.sum()
        row = {"phase_id": ph["phase_id"], "duration_s": b - a, "covered_s": covered,
               "n_samples": int((ov > 0).sum())}
        for j, c in enumerate(cols):
            e = np.nansum(P[:, j] * ov)
            row[c.replace("_w", "_energy_j")] = e
            row[c.replace("_w", "_mean_w")] = e / covered if covered > 0 else np.nan
        m = ov > 0
        if m.any():
            row["thermal_max"] = samples.loc[m, "thermal_level"].max()
            for c in freq_cols:
                row[c] = np.average(samples.loc[m, c], weights=ov[m]) if samples.loc[m, c].notna().all() else np.nan
        out.append(row)
    return pd.DataFrame(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("run_dir")
    ap.add_argument("--plist", default=None)
    a = ap.parse_args()
    plist = a.plist or os.path.join(a.run_dir, "powermetrics.plist")
    samples, bad = read_samples(plist)
    phases = pd.read_csv(os.path.join(a.run_dir, "phases.csv"))
    samples.to_csv(os.path.join(a.run_dir, "power_samples.csv"), index=False)
    pp = integrate(samples, phases)
    pp.to_csv(os.path.join(a.run_dir, "phase_power.csv"), index=False)
    cov = pp["covered_s"] / pp["duration_s"]
    print(f"{len(samples)} samples ({bad} unreadable), {samples['t_start'].min():.0f}-{samples['t_end'].max():.0f}; "
          f"{len(phases)} phases, coverage min {cov.min():.3f} median {cov.median():.3f}")
    gaps = np.diff(samples["t_end"]) - samples["elapsed_s"].iloc[1:].to_numpy()
    print(f"sample interval median {samples['elapsed_s'].median():.3f}s, max gap {np.abs(gaps).max():.3f}s")
    print(pp.merge(phases[["phase_id", "dataset", "tier", "kind"]]).groupby(["kind"])["cpu_mean_w"].describe())


if __name__ == "__main__":
    main()
