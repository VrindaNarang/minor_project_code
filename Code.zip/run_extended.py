"""Extended measurement run (second study).

Two datasets (Fashion-MNIST and the SMS Spam Collection), seven tiers each
(logistic regression, MLP, CNN, int8 CNN, k-NN, RBF SVM, random forest), ten
rounds, single-sample AND batched inference blocks, a cool-down pause and an
idle baseline before every round, and a phase log for powermetrics.

The three original tiers keep the original design (common.py models,
10 epochs, Adam lr 1e-3, batch 64, seeds 1000+r).

Each round r:
    cool-down (untracked)  ->  idle baseline (tracked)
    for each dataset (order alternates):
        for each unit (order rotates):  train (tracked) -> evaluate (untracked)
            -> warm-up -> single-sample block (tracked) -> warm-up -> batched block (tracked)
        (the "cnn" unit is followed directly by quantisation and the int8 tier)
End: a final idle baseline.

Usage:
    python run_extended.py --quick     # a few minutes, to check everything works
    python run_extended.py             # full run (about 5 hours)

For measured power, start in another terminal BEFORE this script and stop it
(Ctrl-C) after this script prints "Done.":
    sudo powermetrics -i 1000 --samplers cpu_power,gpu_power,thermal -f plist -o <out>/powermetrics.plist
"""
import argparse
import math
import os
import subprocess
import time
from datetime import datetime

import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import f1_score
from threadpoolctl import threadpool_limits

from common import CCTracker, count_macs, count_params, describe_environment, load_fashion_mnist, save_json, set_seed
from extended import (EXT_TIERS, SMS_TFIDF, SVM_TRAIN_LIMIT, Both, PhaseLog, TextCNN, VecLogReg, VecMLP, Vocab,
                      build_model, build_sklearn, load_sms, quantize_int8, sms_macs)
from run_experiment import CSVLog

UNITS = ["logreg", "mlp", "cnn", "knn", "svm", "rf"]   # "cnn" also produces "cnn_int8"


def parse():
    p = argparse.ArgumentParser()
    p.add_argument("--out", default="results_ext")
    p.add_argument("--data", default="data")
    p.add_argument("--runs", type=int, default=10)
    p.add_argument("--epochs", type=int, default=10)
    p.add_argument("--batch", type=int, default=64)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--threads", type=int, default=4)
    p.add_argument("--single-s", type=float, default=90.0, help="target length of a single-sample block")
    p.add_argument("--batched-s", type=float, default=20.0, help="target length of a batched block")
    p.add_argument("--infer-batch", type=int, default=32)
    p.add_argument("--warmup", type=int, default=100)
    p.add_argument("--idle-s", type=float, default=30.0)
    p.add_argument("--cooldown-s", type=float, default=60.0)
    p.add_argument("--interval", type=float, default=1.0)
    p.add_argument("--country", default="IND")
    p.add_argument("--datasets", default="fmnist,sms")
    p.add_argument("--nnpack", action="store_true",
                   help="keep PyTorch's NNPACK convolution path (default: off; on this machine it made CNN "
                        "training 1.7x and batched text-CNN inference 34x slower)")
    p.add_argument("--quick", action="store_true")
    a = p.parse_args()
    if a.quick:
        a.runs, a.epochs, a.single_s, a.batched_s, a.idle_s, a.cooldown_s = 2, 1, 3.0, 2.0, 3.0, 2.0
        a.warmup = 10
    return a


# ----------------------------------------------------------------------- shared helpers
def train_loop(make_model, x, y, x_val, y_val, seed, epochs, bs, lr):
    """Same loop as run_experiment.train_torch (seeded model, Adam, shuffled mini-batches,
    validation after every epoch); the caller wraps it in a tracker."""
    set_seed(seed)
    model = make_model()
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.CrossEntropyLoss()
    g = torch.Generator().manual_seed(seed)
    log = []
    t0 = time.perf_counter()
    for ep in range(1, epochs + 1):
        model.train()
        perm = torch.randperm(len(x), generator=g)
        total = 0.0
        for i in range(0, len(x), bs):
            idx = perm[i:i + bs]
            opt.zero_grad(set_to_none=True)
            loss = loss_fn(model(x[idx]), y[idx])
            loss.backward()
            opt.step()
            total += loss.item() * len(idx)
        val_acc = (predict_torch(model, x_val) == y_val).float().mean().item()
        log.append({"epoch": ep, "train_loss": total / len(x), "val_acc": val_acc,
                    "elapsed_s": time.perf_counter() - t0})
    return model, log


def predict_torch(model, x, bs=1000):
    model.eval()
    with torch.inference_mode():
        return torch.cat([model(x[i:i + bs]).argmax(1) for i in range(0, len(x), bs)])


def run_calls(fn, inputs, m):
    n = len(inputs)
    for i in range(m):
        fn(inputs[i % n])


def calibrate(fn, inputs, target_s, min_s=2.0):
    """Number of calls that takes about `target_s` seconds (rounded up to 100)."""
    run_calls(fn, inputs, 5)
    k, t0 = 0, time.perf_counter()
    while time.perf_counter() - t0 < min_s or k < 20:
        fn(inputs[k % len(inputs)])
        k += 1
    per_call = (time.perf_counter() - t0) / k
    return max(100, int(math.ceil(target_s / per_call / 100) * 100)), per_call


# ---------------------------------------------------------------------------- datasets
class FMNISTTask:
    name = "fmnist"

    def __init__(self, a):
        D = load_fashion_mnist(a.data)
        if a.quick:
            D["x_train"], D["y_train"] = D["x_train"][:6000], D["y_train"][:6000]
        self.D = D
        self.X = D["x_train"].flatten(1).numpy()
        self.y = D["y_train"].numpy()
        self.Xt = D["x_test"].flatten(1).numpy()
        self.y_test = D["y_test"].numpy()
        B = a.infer_batch
        self.single = {"torch": [D["x_test"][i:i + 1].contiguous() for i in range(1000)],
                       "np": [self.Xt[i:i + 1].copy() for i in range(1000)]}
        self.batched = {"torch": [D["x_test"][i * B:(i + 1) * B].contiguous() for i in range(100)],
                        "np": [self.Xt[i * B:(i + 1) * B].copy() for i in range(100)]}
        self.svm_n = min(SVM_TRAIN_LIMIT, len(self.X))

    def train_torch(self, tier, seed, a):
        D = self.D
        model, log = train_loop(lambda: build_model(tier), D["x_train"], D["y_train"], D["x_val"], D["y_val"],
                                seed, a.epochs, a.batch, a.lr)
        return {"model": model}, log

    def calib_batches(self):
        g = torch.Generator().manual_seed(0)
        idx = torch.randperm(len(self.D["x_train"]), generator=g)[:1000]
        return [self.D["x_train"][idx[i:i + 100]] for i in range(0, 1000, 100)], self.D["x_train"][:1]

    def train_sk(self, tier, seed):
        clf = build_sklearn(tier, seed)
        n = self.svm_n if tier == "svm" else len(self.X)
        clf.fit(self.X[:n], self.y[:n])
        return {"clf": clf, "n_train": n}

    def test_preds(self, tier, st):
        if "clf" in st:
            return np.asarray(st["clf"].predict(self.Xt))
        return predict_torch(st["model"], self.D["x_test"]).numpy()

    def predictors(self, tier, st):
        if "clf" in st:
            clf = st["clf"]
            if tier == "rf":
                clf.n_jobs = 1          # joblib start-up per call costs more than one tree walk; see Ch. 3
            f = lambda x: clf.predict(x)
            return f, f, self.single["np"], self.batched["np"]
        m = st["model"].eval()

        def f(x):
            with torch.inference_mode():
                return m(x).argmax(1)
        return f, f, self.single["torch"], self.batched["torch"]

    def facts(self, tier, st):
        if tier in ("logreg", "mlp", "cnn"):
            return {"params": count_params(st["model"]), "macs": count_macs(tier)}
        if tier == "cnn_int8":
            return {"params": count_params(build_model("cnn")), "macs": count_macs("cnn"), "bits": 8}
        clf = st["clf"]
        if tier == "knn":
            return {"stored_values": int(len(self.X) * 784), "macs": int(len(self.X) * 784)}
        if tier == "svm":
            nsv = int(clf.n_support_.sum())
            return {"support_vectors": nsv, "stored_values": nsv * 784, "macs": nsv * 784,
                    "train_n": st["n_train"]}
        if tier == "rf":
            nodes = int(sum(e.tree_.node_count for e in clf.estimators_))
            depth = float(np.mean([e.tree_.max_depth for e in clf.estimators_]))
            return {"tree_nodes": nodes, "mean_depth": depth, "macs": None}


class SMSTask:
    name = "sms"

    def __init__(self, a):
        S = load_sms(a.data)
        self.S = S
        self.y = S["y_train"]
        self.y_test = S["y_test"]
        B = a.infer_batch
        tt = S["t_test"]
        n = len(tt)
        self.single = [tt[i % n] for i in range(1000)]
        self.batched = [[tt[(i * B + j) % n] for j in range(B)] for i in range(100)]

    # TF-IDF tiers fit their vectoriser inside the training tracker; the CNN builds its vocabulary there.
    def _tfidf(self):
        from sklearn.feature_extraction.text import TfidfVectorizer
        vec = TfidfVectorizer(**SMS_TFIDF)
        Xs = vec.fit_transform(self.S["t_train"])
        return vec, Xs

    def train_torch(self, tier, seed, a):
        S = self.S
        y = torch.from_numpy(S["y_train"]).long()
        yv = torch.from_numpy(S["y_val"]).long()
        if tier == "cnn":
            vocab = Vocab(S["t_train"])
            x, xv = vocab.encode(S["t_train"]), vocab.encode(S["t_val"])
            model, log = train_loop(lambda: TextCNN(len(vocab.itos)), x, y, xv, yv, seed, a.epochs, a.batch, a.lr)
            return {"model": model, "vocab": vocab}, log
        vec, Xs = self._tfidf()
        x = torch.from_numpy(Xs.toarray().astype(np.float32))
        xv = torch.from_numpy(vec.transform(S["t_val"]).toarray().astype(np.float32))
        d = x.shape[1]
        make = (lambda: VecLogReg(d)) if tier == "logreg" else (lambda: VecMLP(d))
        model, log = train_loop(make, x, y, xv, yv, seed, a.epochs, a.batch, a.lr)
        return {"model": model, "vec": vec}, log

    def calib_batches(self, st):
        x = st["vocab"].encode(self.S["t_train"][:1000])
        return [x[i:i + 100] for i in range(0, 1000, 100)], x[:1]

    def train_sk(self, tier, seed):
        vec, Xs = self._tfidf()
        clf = build_sklearn(tier, seed, sparse=True)
        clf.fit(Xs, self.y)
        return {"clf": clf, "vec": vec, "n_train": Xs.shape[0], "d": Xs.shape[1]}

    def test_preds(self, tier, st):
        tt = self.S["t_test"]
        if "clf" in st:
            return np.asarray(st["clf"].predict(st["vec"].transform(tt)))
        if "vocab" in st:
            return predict_torch(st["model"], st["vocab"].encode(tt)).numpy()
        x = torch.from_numpy(st["vec"].transform(tt).toarray().astype(np.float32))
        return predict_torch(st["model"], x).numpy()

    def predictors(self, tier, st):
        """Every call starts from the raw message: feature extraction is part of the cost."""
        if "clf" in st:
            clf, vec = st["clf"], st["vec"]
            if tier == "rf":
                clf.n_jobs = 1
            one = lambda s: clf.predict(vec.transform([s]))
            many = lambda b: clf.predict(vec.transform(b))
            return one, many, self.single, self.batched
        m = st["model"].eval()
        if "vocab" in st:
            voc = st["vocab"]
            enc_one, enc_many = (lambda s: voc.encode([s])), voc.encode
        else:
            vec = st["vec"]
            enc_many = lambda b: torch.from_numpy(vec.transform(b).toarray().astype(np.float32))
            enc_one = lambda s: enc_many([s])

        def one(s):
            with torch.inference_mode():
                return m(enc_one(s)).argmax(1)

        def many(b):
            with torch.inference_mode():
                return m(enc_many(b)).argmax(1)
        return one, many, self.single, self.batched

    def facts(self, tier, st):
        if tier in ("logreg", "mlp"):
            d = len(st["vec"].vocabulary_)
            return {"params": count_params(st["model"]), "macs": sms_macs(tier, d), "tfidf_dim": d}
        if tier in ("cnn", "cnn_int8"):
            v = len(st["vocab"].itos)
            f = {"params": count_params(TextCNN(v)), "macs": sms_macs("cnn", 0), "vocab": v}
            if tier == "cnn_int8":
                f["bits"] = 8
            return f
        clf, d, n = st["clf"], st["d"], st["n_train"]
        if tier == "knn":
            return {"stored_values": n * d, "macs": n * d, "tfidf_dim": d, "note": "dense-equivalent"}
        if tier == "svm":
            nsv = int(clf.n_support_.sum())
            return {"support_vectors": nsv, "macs": nsv * d, "tfidf_dim": d, "note": "dense-equivalent"}
        if tier == "rf":
            nodes = int(sum(e.tree_.node_count for e in clf.estimators_))
            depth = float(np.mean([e.tree_.max_depth for e in clf.estimators_]))
            return {"tree_nodes": nodes, "mean_depth": depth, "macs": None}


# --------------------------------------------------------------------------------- main
def main():
    a = parse()
    torch.set_num_threads(a.threads)
    torch.backends.nnpack.set_flags(a.nnpack)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    out = os.path.join(a.out, stamp + ("-quick" if a.quick else ""))
    os.makedirs(out, exist_ok=True)
    print(f"Writing results to {out}", flush=True)

    env = describe_environment(a.threads)
    env["args"] = vars(a)
    env["started"] = datetime.now().isoformat()
    env["started_unix"] = time.time()
    env["nnpack_enabled"] = bool(a.nnpack)
    save_json(env, os.path.join(out, "environment.json"))

    tasks = {}
    for name in a.datasets.split(","):
        tasks[name] = FMNISTTask(a) if name == "fmnist" else SMSTask(a)
    logs = {k: CSVLog(os.path.join(out, f"{k}.csv"))
            for k in ["train_runs", "epoch_log", "inference_blocks", "idle"]}
    phases = PhaseLog(os.path.join(out, "phases.csv"))
    block_calls, per_call_est, facts = {}, {}, {}
    ds_names = list(tasks)

    def tracked(ds, r, tier, kind, calls=None, batch=None):
        return Both(CCTracker(a.country, a.interval, out), phases.phase(ds, r, tier, kind, calls, batch))

    def idle(r, when):
        with tracked("-", r, "-", "idle") as b:
            time.sleep(a.idle_s)
        logs["idle"].write({"round": r, "when": when, "phase_id": b.phase_id, **b.result})
        return b.result["energy_kwh"] * 3.6e6 / b.result["duration_s"]

    def measure(task, r, seed, tier, st, train_res, train_phase, epoch_log, idle_w, extra_train=None):
        ds = task.name
        preds = task.test_preds(tier, st)
        acc = float((preds == task.y_test).mean())
        f1 = float(f1_score(task.y_test, preds, average="macro"))
        logs["train_runs"].write({"dataset": ds, "round": r, "seed": seed, "tier": tier, "test_acc": acc,
                                  "test_f1": f1, "phase_id": train_phase, "extra": extra_train,
                                  "idle_power_w": idle_w, **train_res})
        for e in epoch_log:
            logs["epoch_log"].write({"dataset": ds, "round": r, "tier": tier, **e})
        if r == 0:
            np.save(os.path.join(out, f"test_preds_{ds}_{tier}.npy"), preds)
            facts.setdefault(ds, {})[tier] = task.facts(tier, st)
            save_json(facts, os.path.join(out, "model_facts.json"))
        print(f"  [{ds}] {tier:8s} train {train_res['duration_s']:7.1f}s {train_res['energy_kwh'] * 1000:8.4f} Wh"
              f"  acc {acc:.4f}", flush=True)

        one, many, xs1, xsb = task.predictors(tier, st)
        for mode, fn, xs, bsz, target in [("single", one, xs1, 1, a.single_s),
                                         ("batched", many, xsb, a.infer_batch, a.batched_s)]:
            key = f"{ds}/{tier}/{mode}"
            if key not in block_calls:
                block_calls[key], per_call_est[key] = calibrate(fn, xs, target)
                print(f"    calibrated {key}: {per_call_est[key] * 1e6:.1f} us/call -> M = {block_calls[key]:,}",
                      flush=True)
            m = block_calls[key]
            run_calls(fn, xs, a.warmup if mode == "single" else max(5, a.warmup // 10))
            with tracked(ds, r, tier, f"infer_{mode}", m, bsz) as b:
                run_calls(fn, xs, m)
            logs["inference_blocks"].write({"dataset": ds, "round": r, "tier": tier, "mode": mode, "calls": m,
                                            "batch": bsz, "predictions": m * bsz, "phase_id": b.phase_id,
                                            "idle_power_w": idle_w, **b.result})
            print(f"    {mode:7s} {b.result['duration_s']:6.1f}s "
                  f"{b.result['energy_kwh'] * 3.6e9 / (m * bsz):9.4f} mJ/prediction gross (CodeCarbon)", flush=True)

    with threadpool_limits(a.threads):
        for r in range(a.runs):
            seed = 1000 + r
            print(f"\n=== Round {r + 1}/{a.runs}  seed {seed}", flush=True)
            with phases.phase("-", r, "-", "cooldown"):
                time.sleep(a.cooldown_s)
            idle_w = idle(r, "start")
            print(f"  idle {idle_w:.2f} W (CodeCarbon)", flush=True)
            for ds in ds_names[r % len(ds_names):] + ds_names[:r % len(ds_names)]:
                task = tasks[ds]
                order = UNITS[r % len(UNITS):] + UNITS[:r % len(UNITS)]
                for unit in order:
                    if unit in ("logreg", "mlp", "cnn"):
                        with tracked(ds, r, unit, "train") as b:
                            st, ep = task.train_torch(unit, seed, a)
                        measure(task, r, seed, unit, st, b.result, b.phase_id, ep, idle_w)
                        if unit == "cnn":
                            cb, ex = task.calib_batches() if ds == "fmnist" else task.calib_batches(st)
                            with tracked(ds, r, "cnn_int8", "quantize") as bq:
                                q = quantize_int8(st["model"], cb, ex)
                            st_q = dict(st, model=q)
                            # int8 training cost = this round's CNN training + quantisation (added in analysis)
                            measure(task, r, seed, "cnn_int8", st_q, bq.result, bq.phase_id, [], idle_w,
                                    extra_train=f"cnn_train_phase={b.phase_id}")
                    else:
                        with tracked(ds, r, unit, "train") as b:
                            st = task.train_sk(unit, seed)
                        measure(task, r, seed, unit, st, b.result, b.phase_id, [], idle_w)
        idle(a.runs, "end")

    env["finished"] = datetime.now().isoformat()
    env["finished_unix"] = time.time()
    env["block_calls"] = block_calls
    env["per_call_estimate_s"] = per_call_est
    env["power_source_end"] = subprocess.run(["pmset", "-g", "batt"], capture_output=True, text=True).stdout
    save_json(env, os.path.join(out, "environment.json"))
    print(f"\nDone. Now stop powermetrics (Ctrl-C) and run:  python analyze_extended.py {out}", flush=True)


if __name__ == "__main__":
    main()
