"""Analysis of the extended run (and, optionally, the add-on run) for the paper.

Energy per phase is taken from powermetrics (primary): mean combined
CPU+GPU+ANE power over the phase x phase duration. CodeCarbon's estimate for
the same phase is kept as a cross-check. Net energy subtracts the round's idle
power (same source) over the phase duration.

Usage:
    python analyze_extended.py <ext_run_dir> [--addon <addon_run_dir>] [--out paper_out]
Writes summary.json, tables/*.tex and figures/*.pdf into --out.
"""
import argparse
import json
import os

import numpy as np
import pandas as pd

LABEL = {"logreg": "LR", "mlp": "MLP", "cnn": "CNN", "cnn_int8": "CNN-int8", "knn": "k-NN", "svm": "RBF-SVM",
         "rf": "RF", "linsvm": "Lin-SVM", "decider": "Decider-2B"}
COLOR = {"logreg": "#2a78d6", "mlp": "#eb6834", "cnn": "#1baf7a", "cnn_int8": "#eda100", "knn": "#e87ba4",
         "svm": "#008300", "rf": "#6250d6", "decider": "#e34948", "linsvm": "#52514e"}
STYLE = {"logreg": "-", "mlp": "--", "cnn": "-", "cnn_int8": ":", "knn": "-.", "svm": "--", "rf": ":",
         "decider": "-", "linsvm": "-."}
DSNAME = {"fmnist": "Fashion-MNIST", "sms": "SMS Spam", "iris": "Iris", "breast_cancer": "Breast Cancer",
          "wine": "Wine"}
FLOORS = {"fmnist": [0.0, 0.85, 0.87, 0.90], "sms": [0.0, 0.95, 0.98]}   # illustrative accuracy floors
REGIME_N = np.logspace(0, 9, 91)
RNG = np.random.default_rng(12345)
BOOT_SEED = {"fmnist": 1, "sms": 2, "iris": 3, "breast_cancer": 4, "wine": 5}
B = 10000
J_PER_KWH = 3.6e6
GRID_KG_PER_KWH = 0.727   # India, weighted average 2023-24, CEA CO2 Baseline Database v20.0


# ----------------------------------------------------------------------------- loading
def phase_energy(run):
    """Per-phase gross/net energy (J) from powermetrics and CodeCarbon."""
    ph = pd.read_csv(os.path.join(run, "phases.csv"))
    pp = pd.read_csv(os.path.join(run, "phase_power.csv"))
    ph = ph.merge(pp[["phase_id", "combined_mean_w", "cpu_mean_w", "gpu_mean_w", "covered_s", "thermal_max"]
                     + [c for c in pp.columns if c.startswith("freq_")]], on="phase_id", how="left")
    ph["dur"] = ph["t_end"] - ph["t_start"]
    # A phase shorter than the 1 s sampling interval can fall between two samples; use the
    # power of the sample nearest its midpoint (affects only phases of ~0.1 s).
    miss = ph["combined_mean_w"].isna()
    ph["power_filled"] = miss
    if miss.any():
        s = pd.read_csv(os.path.join(run, "power_samples.csv"))
        mid_s = ((s["t_start"] + s["t_end"]) / 2).to_numpy()
        for i in ph.index[miss]:
            mid = (ph.at[i, "t_start"] + ph.at[i, "t_end"]) / 2
            ph.at[i, "combined_mean_w"] = s["combined_w"].iloc[int(np.argmin(np.abs(mid_s - mid)))]
    ph["pm_gross_j"] = ph["combined_mean_w"] * ph["dur"]
    idle = ph[ph["kind"] == "idle"].set_index("round")["combined_mean_w"]
    ph["idle_w"] = ph["round"].map(idle).fillna(idle.mean())
    ph["pm_net_j"] = (ph["combined_mean_w"] - ph["idle_w"]) * ph["dur"]
    return ph


def cc_energy(run):
    """CodeCarbon energy (J) per phase, joined through the CSV logs."""
    rows = []
    for f in ["train_runs", "inference_blocks", "idle"]:
        p = os.path.join(run, f + ".csv")
        if os.path.exists(p):
            d = pd.read_csv(p)
            rows.append(d[["phase_id", "energy_kwh", "duration_s"]])
    d = pd.concat(rows)
    d["cc_gross_j"] = d["energy_kwh"] * J_PER_KWH
    return d[["phase_id", "cc_gross_j"]]


def build_table(run):
    """Per (dataset, tier, round): train J, prep J, infer J per prediction (single, batched), accuracy."""
    ph = phase_energy(run).merge(cc_energy(run), on="phase_id", how="left")
    tr = pd.read_csv(os.path.join(run, "train_runs.csv"))
    ib = pd.read_csv(os.path.join(run, "inference_blocks.csv"))
    e = ph.set_index("phase_id")
    out = []
    for _, r in tr.iterrows():
        row = {"dataset": r["dataset"], "tier": r["tier"], "round": r["round"], "acc": r["test_acc"],
               "f1": r["test_f1"]}
        for k in ["pm_gross_j", "pm_net_j", "cc_gross_j", "dur"]:
            row[f"train_{k}"] = e.loc[r["phase_id"], k]
        if r["tier"] == "cnn_int8":                 # int8 = CNN training of the same round + quantisation
            cnn_pid = int(str(r["extra"]).split("=")[1])
            for k in ["pm_gross_j", "pm_net_j", "cc_gross_j", "dur"]:
                row[f"train_{k}"] += e.loc[cnn_pid, k]
        if "prep_phase_id" in r and not pd.isna(r.get("prep_phase_id")):
            for k in ["pm_gross_j", "pm_net_j", "cc_gross_j"]:
                row[f"prep_{k}"] = e.loc[int(r["prep_phase_id"]), k]
        out.append(row)
    T = pd.DataFrame(out)
    for c in ["prep_pm_gross_j", "prep_pm_net_j", "prep_cc_gross_j"]:
        if c not in T:
            T[c] = 0.0
    T[[c for c in T if c.startswith("prep_")]] = T[[c for c in T if c.startswith("prep_")]].fillna(0.0)
    inf = []
    for _, r in ib.iterrows():
        p = e.loc[r["phase_id"]]
        inf.append({"dataset": r["dataset"], "tier": r["tier"], "round": r["round"], "mode": r["mode"],
                    "n": r["predictions"], "dur": p["dur"], "infer_pm_gross_j": p["pm_gross_j"] / r["predictions"],
                    "infer_pm_net_j": p["pm_net_j"] / r["predictions"],
                    "infer_cc_gross_j": p["cc_gross_j"] / r["predictions"],
                    "latency_s": p["dur"] / r["calls"], "thermal_max": p["thermal_max"]})
    I = pd.DataFrame(inf)
    return T, I, ph


# ------------------------------------------------------------------------------ maths
def classify(a_tr, a_in, b_tr, b_in):
    """Crossover of A (cheaper to set up) vs B. Returns (case, N*)."""
    d_tr, d_in = b_tr - a_tr, a_in - b_in
    if d_in == 0:
        return "parallel", np.nan
    n = d_tr / d_in
    return ("crossover", n) if n > 0 else ("dominance", np.nan)


def mean_ci(x):
    x = np.asarray(x, float)
    m = x.mean()
    bs = RNG.choice(x, (B, len(x))).mean(1)
    return m, np.percentile(bs, 2.5), np.percentile(bs, 97.5), x.std(ddof=1) / m * 100 if m else np.nan


def boot_means(x):
    x = np.asarray(x, float)
    return RNG.choice(x, (B, len(x))).mean(1)


# ----------------------------------------------------------------------------- analysis
def analyse(T, I, basis="pm_gross", mode="single"):
    """Per dataset: summary per tier, pairwise crossovers, bootstrap draws for the selector."""
    res = {}
    for ds, Td in T.groupby("dataset"):
        Id = I[(I["dataset"] == ds) & (I["mode"] == mode)]
        tiers = [t for t in LABEL if t in set(Td["tier"])]
        S, draws = {}, {}
        # Paired bootstrap: one set of resampled rounds per dataset, shared by every tier and quantity
        rounds = sorted(set(Td["round"]))
        idx = np.random.default_rng(BOOT_SEED[ds]).integers(0, len(rounds), (B, len(rounds)))

        def paired(df, col):
            v = df.groupby("round")[col].mean().reindex(rounds).to_numpy(float)
            return np.nanmean(v[idx], axis=1)
        for t in tiers:
            tt, ii = Td[Td["tier"] == t], Id[Id["tier"] == t]
            setup = tt[f"train_{basis}_j"] + tt[f"prep_{basis}_j"]
            tts = tt.assign(_setup=setup)
            S[t] = {"setup_j": mean_ci(setup), "train_j": mean_ci(tt[f"train_{basis}_j"]),
                    "prep_j": float(tt[f"prep_{basis}_j"].mean()),
                    "infer_j": mean_ci(ii[f"infer_{basis}_j"]) if len(ii) else None,
                    "acc": mean_ci(tt["acc"]), "f1": float(tt["f1"].mean()), "train_s": float(tt["train_dur"].mean()),
                    "latency_s": float(ii["latency_s"].mean()) if len(ii) else None, "rounds": int(len(tt))}
            draws[t] = (paired(tts, "_setup"), paired(ii, f"infer_{basis}_j") if len(ii) else None,
                        paired(tt, "acc"))
        pairs = {}
        for i, a in enumerate(tiers):
            for b in tiers[i + 1:]:
                if S[a]["infer_j"] is None or S[b]["infer_j"] is None:
                    continue
                A, Bt = (a, b) if S[a]["setup_j"][0] <= S[b]["setup_j"][0] else (b, a)
                case, n = classify(S[A]["setup_j"][0], S[A]["infer_j"][0], S[Bt]["setup_j"][0], S[Bt]["infer_j"][0])
                d_tr = draws[Bt][0] - draws[A][0]
                d_in = draws[A][1] - draws[Bt][1]
                with np.errstate(divide="ignore", invalid="ignore"):
                    nb = d_tr / d_in
                ok = (d_in != 0) & (nb > 0)
                pairs[f"{A}|{Bt}"] = {"A": A, "B": Bt, "case": case, "nstar": n, "p_cross": float(ok.mean()),
                                      "ci": [float(np.percentile(nb[ok], 2.5)), float(np.percentile(nb[ok], 97.5))]
                                      if ok.sum() > 100 else None}
        res[ds] = {"tiers": tiers, "S": S, "pairs": pairs, "draws": draws}
    return res


def selector(draws, tiers, Ns, floors):
    """P(tier is the lowest-energy choice meeting the accuracy floor), over bootstrap draws."""
    out = {}
    for f in floors:
        for N in Ns:
            tot = np.full((B, len(tiers)), np.inf)
            for j, t in enumerate(tiers):
                s, i, acc = draws[t]
                if i is None:
                    continue
                v = s + N * i
                tot[:, j] = np.where(acc >= f, v, np.inf)
            best = np.argmin(tot, 1)
            none = ~np.isfinite(tot.min(1))
            out[(f, N)] = {t: float(((best == j) & ~none).mean()) for j, t in enumerate(tiers)}
            out[(f, N)]["none"] = float(none.mean())
    return out


# ------------------------------------------------------------------------------ output
def fmt(x, sig=3):
    if x is None or (isinstance(x, float) and not np.isfinite(x)):
        return "--"
    if x == 0:
        return "0"
    e = int(np.floor(np.log10(abs(x))))
    if -3 <= e < 5:
        return f"{x:.{max(0, sig - 1 - e)}f}"
    m = x / 10 ** e
    return f"${m:.{sig - 1}f}\\times10^{{{e}}}$"


def sci(x):
    return fmt(x)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("run")
    ap.add_argument("--addon", default=None)
    ap.add_argument("--out", default="paper_out")
    a = ap.parse_args()
    os.makedirs(os.path.join(a.out, "tables"), exist_ok=True)
    os.makedirs(os.path.join(a.out, "figures"), exist_ok=True)

    T, I, ph = build_table(a.run)
    summary = {"main": {}, "addon": {}}
    R = {b: analyse(T, I, b, "single") for b in ["pm_gross", "pm_net", "cc_gross"]}
    Rb = analyse(T, I, "pm_gross", "batched")

    # ---- per-dataset summaries
    for ds in R["pm_gross"]:
        g = R["pm_gross"][ds]
        d = summary["main"][ds] = {"tiers": {}, "pairs": {}, "pairs_net": {}, "pairs_cc": {}, "pairs_batched": {}}
        for t in g["tiers"]:
            s = g["S"][t]
            n = R["pm_net"][ds]["S"][t]
            c = R["cc_gross"][ds]["S"][t]
            sb = Rb[ds]["S"][t]
            d["tiers"][t] = {
                "train_gross_j": s["train_j"][0], "train_gross_ci": s["train_j"][1:3], "train_cv": s["train_j"][3],
                "train_net_j": n["train_j"][0], "train_net_cv": n["train_j"][3],
                "infer_gross_j": s["infer_j"][0], "infer_gross_ci": s["infer_j"][1:3], "infer_cv": s["infer_j"][3],
                "infer_net_j": n["infer_j"][0], "infer_net_cv": n["infer_j"][3],
                "infer_batched_gross_j": sb["infer_j"][0] if sb["infer_j"] else None,
                "batch_gain": s["infer_j"][0] / sb["infer_j"][0] if sb["infer_j"] else None,
                "cc_train_j": c["train_j"][0], "cc_infer_j": c["infer_j"][0],
                "cc_over_pm_train": c["train_j"][0] / s["train_j"][0], "cc_over_pm_infer": c["infer_j"][0] / s["infer_j"][0],
                "acc": s["acc"][0], "acc_ci": s["acc"][1:3], "f1": s["f1"], "train_s": s["train_s"],
                "latency_s": s["latency_s"], "rounds": s["rounds"],
                "infer_share_1e6": 1e6 * s["infer_j"][0] / (s["setup_j"][0] + 1e6 * s["infer_j"][0]),
                "co2_g_1e6": (s["setup_j"][0] + 1e6 * s["infer_j"][0]) / J_PER_KWH * GRID_KG_PER_KWH * 1e3,
            }
        for key, src in [("pairs", R["pm_gross"]), ("pairs_net", R["pm_net"]), ("pairs_cc", R["cc_gross"]),
                         ("pairs_batched", Rb)]:
            for k, p in src[ds]["pairs"].items():
                d[key][k] = {kk: vv for kk, vv in p.items()}
        sel = selector(g["draws"], g["tiers"], [1e2, 1e4, 1e6, 1e8], [0.0])
        d["selector_any_acc"] = {f"{int(N):.0e}": v for (f, N), v in sel.items()}
        sel = selector(g["draws"], g["tiers"], REGIME_N, FLOORS[ds])
        d["regime"] = {str(f): [{"N": float(N), **sel[(f, N)]} for N in REGIME_N] for f in FLOORS[ds]}
        d["floors"] = FLOORS[ds]

    # ---- idle & thermal
    idle = ph[ph["kind"] == "idle"]
    summary["main"]["_idle_w"] = mean_ci(idle["combined_mean_w"])[:4]
    summary["main"]["_thermal_max"] = float(np.nanmax(ph["thermal_max"]))
    summary["main"]["_power_filled_phases"] = ph.loc[ph["power_filled"], ["kind", "dataset", "tier", "dur"]] \
        .to_dict("records")
    ps = pd.read_csv(os.path.join(a.run, "power_samples.csv"))
    ps = ps[(ps["t_end"] >= ph["t_start"].min()) & (ps["t_start"] <= ph["t_end"].max())]
    th = {"share_by_level": ps["thermal_pressure"].value_counts(normalize=True).to_dict(), "per_round": []}
    for r, g in ph[ph["round"] >= 0].groupby("round"):
        m = (ps["t_start"] >= g["t_start"].min()) & (ps["t_end"] <= g["t_end"].max())
        x = ps[m]
        busy = x[x["busy_S"] > 0.5]
        th["per_round"].append({"round": int(r), "heavy_share": float((x["thermal_level"] >= 2).mean()),
                                "s_freq_busy_median_mhz": float(busy["freq_S_mhz"].median()),
                                "minutes": float((g["t_end"].max() - g["t_start"].min()) / 60)})
    summary["main"]["_thermal"] = th
    pw = ph[ph["kind"].isin(["infer_single", "infer_batched", "train"])].groupby("kind")[
        ["cpu_mean_w", "gpu_mean_w", "combined_mean_w"]].mean()
    summary["main"]["_mean_power_w"] = {k: v.to_dict() for k, v in pw.iterrows()}
    summary["main"]["_run_hours"] = float((ph["t_end"].max() - ph["t_start"].min()) / 3600)
    # alignment sensitivity: shift samples by +-0.5 s, recompute inference-block mean power
    blocks = ph[ph["kind"].str.startswith("infer")]
    st, en, pw = ps["t_start"].to_numpy(), ps["t_end"].to_numpy(), ps["combined_w"].to_numpy()

    def block_w(shift):
        out = []
        for _, b in blocks.iterrows():
            ov = np.clip(np.minimum(en + shift, b["t_end"]) - np.maximum(st + shift, b["t_start"]), 0, None)
            out.append((ov * pw).sum() / ov.sum() if ov.sum() > 0 else np.nan)
        return np.array(out)
    base = block_w(0.0)
    summary["main"]["_align"] = {str(s): float(np.nanmax(np.abs(block_w(s) / base - 1)) * 100) for s in [-0.5, 0.5]}
    summary["main"]["_align_median"] = {str(s): float(np.nanmedian(np.abs(block_w(s) / base - 1)) * 100)
                                        for s in [-0.5, 0.5]}
    summary["main"]["_cc_idle_w"] = float(pd.read_csv(os.path.join(a.run, "idle.csv"))
                                         .eval("energy_kwh*3.6e6/duration_s").mean())
    env = json.load(open(os.path.join(a.run, "environment.json")))
    summary["main"]["_env"] = {k: env.get(k) for k in ["cpu", "model", "macos", "ram_gb", "torch", "sklearn",
                                                      "codecarbon", "started", "finished", "nnpack_enabled"]}
    summary["main"]["_env"]["args"] = env.get("args")

    # ---- add-on run (tabular + decider)
    if a.addon:
        Ta, Ia, pha = build_table(a.addon)
        dec = pd.read_csv(os.path.join(a.addon, "decider.csv"))
        pa = phase_energy(a.addon)
        load = pa[(pa["tier"] == "decider") & (pa["kind"] == "load")]
        load_j = float(load["pm_gross_j"].sum())
        # Decider rows: setup = model load (one-off), accuracy from the single evaluation pass
        rows = []
        for ds in Ia["dataset"].unique():
            ii = Ia[(Ia["dataset"] == ds) & (Ia["tier"] == "decider")]
            acc = float(dec.loc[dec["dataset"] == ds, "test_acc"].iloc[0])
            f1 = float(dec.loc[dec["dataset"] == ds, "test_f1"].iloc[0])
            for r in sorted(ii["round"].unique()):
                rows.append({"dataset": ds, "tier": "decider", "round": r, "acc": acc, "f1": f1,
                             "train_pm_gross_j": 0.0, "train_pm_net_j": 0.0, "train_cc_gross_j": 0.0, "train_dur": 0.0,
                             "prep_pm_gross_j": load_j, "prep_pm_net_j": float(load["pm_net_j"].sum()),
                             "prep_cc_gross_j": 0.0})
        Ta = pd.concat([Ta, pd.DataFrame(rows)], ignore_index=True)
        Ra = analyse(Ta, Ia, "pm_gross", "single")
        Ran = analyse(Ta, Ia, "pm_net", "single")
        summary["addon"]["_decider_load_j"] = load_j
        summary["addon"]["_decider_load_s"] = float(load["dur"].sum())
        summary["addon"]["_idle_w"] = mean_ci(pa[pa["kind"] == "idle"]["combined_mean_w"])[:4]
        summary["addon"]["_decider_eval"] = dec.to_dict("records")
        # exact McNemar test: Decider vs each trained tier on the same test items (round-0 predictions)
        from scipy.stats import binomtest
        from extended import load_sms
        ytest = {"sms": np.asarray(load_sms(os.path.join(os.path.dirname(__file__) or ".", "data"))["y_test"])}
        for n in ["iris", "breast_cancer", "wine"]:
            import run_addon
            ytest[n] = np.asarray(run_addon.tabular(n)["y_test"])
        mc = {}
        for n, yv in ytest.items():
            pd_ = os.path.join(a.addon, f"test_preds_{n}_decider.npy")
            if not os.path.exists(pd_):
                continue
            dp = np.load(pd_) == yv
            for f in sorted(os.listdir(a.addon)):
                if f.startswith(f"test_preds_{n}_") and not f.endswith("_decider.npy"):
                    t = f[len(f"test_preds_{n}_"):-4]
                    tp = np.load(os.path.join(a.addon, f)) == yv
                    n01, n10 = int((dp & ~tp).sum()), int((~dp & tp).sum())
                    mc[f"{n}/{t}"] = {"n": int(len(yv)), "decider_errors": int((~dp).sum()), "tier_errors": int((~tp).sum()),
                                      "decider_only_right": n01, "tier_only_right": n10,
                                      "p": float(binomtest(n01, n01 + n10, 0.5).pvalue) if n01 + n10 else 1.0}
        summary["addon"]["_mcnemar"] = mc
        pw = pa[pa["kind"].isin(["infer_single", "load"])].groupby(["tier", "kind"])[
            ["cpu_mean_w", "gpu_mean_w", "combined_mean_w"]].mean()
        summary["addon"]["_mean_power_w"] = {f"{t}/{k}": v.to_dict() for (t, k), v in pw.iterrows()}
        for ds, g in Ra.items():
            d = summary["addon"][ds] = {"tiers": {}, "pairs": {}, "pairs_net": {}}
            for t in g["tiers"]:
                s = g["S"][t]
                d["tiers"][t] = {"setup_j": s["setup_j"][0], "prep_j": s["prep_j"], "train_j": s["train_j"][0],
                                 "infer_j": s["infer_j"][0], "infer_ci": s["infer_j"][1:3], "infer_cv": s["infer_j"][3],
                                 "infer_net_j": Ran[ds]["S"][t]["infer_j"][0],
                                 "acc": s["acc"][0], "f1": s["f1"], "latency_s": s["latency_s"],
                                 "co2_g_1e6": (s["setup_j"][0] + 1e6 * s["infer_j"][0]) / J_PER_KWH * GRID_KG_PER_KWH * 1e3}
            for k, p in g["pairs"].items():
                d["pairs"][k] = p
            for k, p in Ran[ds]["pairs"].items():
                d["pairs_net"][k] = p
            sel = selector(g["draws"], g["tiers"], [1, 10, 1e2, 1e3, 1e4, 1e6], [0.0, 0.9])
            d["selector"] = {f"floor={f}|N={int(N):.0e}": v for (f, N), v in sel.items()}
        addon_R = Ra
    else:
        addon_R = None

    with open(os.path.join(a.out, "summary.json"), "w") as f:
        json.dump(summary, f, indent=1, default=lambda o: float(o) if np.isscalar(o) else list(o))
    make_tables(summary, a.out)
    with open(os.path.join(a.out, "summary.json"), "w") as f:
        json.dump(summary, f, indent=1, default=lambda o: float(o) if np.isscalar(o) else list(o))
    make_figures(R, Rb, T, I, ph, addon_R, a.out, summary)
    print("wrote", a.out)


# ------------------------------------------------------------------------------ tables
def make_tables(S, out):
    for ds in ["fmnist", "sms"]:
        if ds not in S["main"]:
            continue
        d = S["main"][ds]["tiers"]
        lines = [r"\begin{tabular}{@{}lrrrrr@{}}", r"\toprule",
                 r"Tier & $E_\mathrm{train}$ (J) & $E_\mathrm{inf}$ ($\mu$J) & CV & Batched ($\mu$J) & Acc. (\%) \\",
                 r"\midrule"]
        for t, v in d.items():
            lines.append(f"{LABEL[t]} & {fmt(v['train_gross_j'])} & {fmt(v['infer_gross_j'] * 1e6)} & "
                         f"{v['infer_cv']:.0f}\\% & {fmt(v['infer_batched_gross_j'] * 1e6)} & "
                         f"{v['acc'] * 100:.2f} \\\\")
        lines += [r"\bottomrule", r"\end{tabular}"]
        open(os.path.join(out, "tables", f"energy_{ds}.tex"), "w").write("\n".join(lines) + "\n")

    # combined main table (both datasets side by side, for a table*)
    if "fmnist" in S["main"] and "sms" in S["main"]:
        lines = [r"\begin{tabular}{@{}l rrrrr c rrrrr@{}}", r"\toprule",
                 r" & \multicolumn{5}{c}{Fashion-MNIST} && \multicolumn{5}{c}{SMS Spam} \\",
                 r"\cmidrule{2-6}\cmidrule{8-12}",
                 r"Tier & $S$ (J) & $E_\mathrm{inf}$ ($\mu$J) & CV & Batch ($\mu$J) & Acc. & & "
                 r"$S$ (J) & $E_\mathrm{inf}$ ($\mu$J) & CV & Batch ($\mu$J) & Acc. \\", r"\midrule"]
        for t in S["main"]["fmnist"]["tiers"]:
            cells = []
            for ds in ["fmnist", "sms"]:
                v = S["main"][ds]["tiers"][t]
                cells.append(f"{fmt(v['train_gross_j'])} & {fmt(v['infer_gross_j'] * 1e6)} & {v['infer_cv']:.0f}\\% & "
                             f"{fmt(v['infer_batched_gross_j'] * 1e6)} & {v['acc'] * 100:.2f}")
            lines.append(f"{LABEL[t]} & {cells[0]} & & {cells[1]} \\\\")
        lines += [r"\bottomrule", r"\end{tabular}"]
        open(os.path.join(out, "tables", "energy_main.tex"), "w").write("\n".join(lines) + "\n")

    # crossover tables (main run, gross, single)
    for ds in ["fmnist", "sms"]:
        if ds not in S["main"]:
            continue
        P = S["main"][ds]["pairs"]
        lines = [r"\begin{tabular}{@{}llrr@{}}", r"\toprule",
                 r"Cheaper setup & Cheaper per call & $N^*$ & $P(\mathrm{cross})$ \\", r"\midrule"]
        for k, p in sorted(P.items(), key=lambda kv: (kv[1]["case"] != "crossover", kv[1]["nstar"]
                                                       if np.isfinite(kv[1]["nstar"]) else 0)):
            if p["case"] != "crossover":
                continue
            lines.append(f"{LABEL[p['A']]} & {LABEL[p['B']]} & {fmt(p['nstar'])} & {p['p_cross']:.2f} \\\\")
        n_dom = sum(p["case"] == "dominance" for p in P.values())
        lines += [r"\midrule", f"\\multicolumn{{4}}{{@{{}}l}}{{Dominance (no crossover): {n_dom} of {len(P)} pairs}} \\\\",
                  r"\bottomrule", r"\end{tabular}"]
        open(os.path.join(out, "tables", f"crossover_{ds}.tex"), "w").write("\n".join(lines) + "\n")

    if S["addon"]:
        lines = [r"\begin{tabular}{@{}llrrrr@{}}", r"\toprule",
                 r"Dataset & Tier & Setup (J) & $E_\mathrm{inf}$ (mJ) & Acc. (\%) & $N^*$ vs.\ Decider \\",
                 r"\midrule"]
        for ds in ["iris", "breast_cancer", "wine", "sms"]:
            if ds not in S["addon"]:
                continue
            d = S["addon"][ds]
            for t, v in d["tiers"].items():
                ns = "--"
                for k, p in d["pairs"].items():
                    if "decider" in k and t in (p["A"], p["B"]) and t != "decider":
                        ns = fmt(p["nstar"]) if p["case"] == "crossover" else "dom."
                lines.append(f"{DSNAME[ds] if t == list(d['tiers'])[0] else ''} & {LABEL[t]} & {fmt(v['setup_j'])} & "
                             f"{fmt(v['infer_j'] * 1e3)} & {v['acc'] * 100:.1f} & {ns} \\\\")
            lines.append(r"\midrule")
        lines[-1] = r"\bottomrule"
        lines.append(r"\end{tabular}")
        open(os.path.join(out, "tables", "decider.tex"), "w").write("\n".join(lines) + "\n")

        # compact version: Decider vs the cheapest-per-call and the most accurate trained tier
        lines = [r"\begin{tabular}{@{}lrrlrrr@{}}", r"\toprule",
                 r" & \multicolumn{2}{c}{Decider-2B} & \multicolumn{3}{c}{Cheapest trained tier} & Best trained \\",
                 r"\cmidrule(lr){2-3}\cmidrule(lr){4-6}",
                 r"Dataset & $E_\mathrm{inf}$ (mJ) & Acc. & Tier & $E_\mathrm{inf}$ (mJ) & Acc. & Acc. \\", r"\midrule"]
        for ds in ["iris", "breast_cancer", "wine", "sms"]:
            if ds not in S["addon"]:
                continue
            d = S["addon"][ds]["tiers"]
            dv = d["decider"]
            tr = {t: v for t, v in d.items() if t != "decider"}
            ch = min(tr, key=lambda t: tr[t]["infer_j"])
            best = max(v["acc"] for v in tr.values())
            lines.append(f"{DSNAME[ds]} & {fmt(dv['infer_j'] * 1e3)} & {dv['acc'] * 100:.1f} & {LABEL[ch]} & "
                         f"{fmt(tr[ch]['infer_j'] * 1e3)} & {tr[ch]['acc'] * 100:.1f} & {best * 100:.1f} \\\\")
            S["addon"][ds]["_ratio_vs_cheapest"] = dv["infer_j"] / tr[ch]["infer_j"]
            S["addon"][ds]["_cheapest"] = ch
        lines += [r"\bottomrule", r"\end{tabular}"]
        open(os.path.join(out, "tables", "decider_compact.tex"), "w").write("\n".join(lines) + "\n")


# ----------------------------------------------------------------------------- figures
def make_figures(R, Rb, T, I, ph, Ra, out, S):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size": 8, "font.family": "serif", "axes.spines.top": False,
                         "axes.spines.right": False, "axes.grid": True, "grid.color": "#e6e5e0",
                         "grid.linewidth": 0.5, "axes.edgecolor": "#8a8984", "legend.frameon": False,
                         "lines.linewidth": 1.4, "pdf.fonttype": 42})
    W1, W2 = 3.5, 7.16
    Ns = np.logspace(0, 10, 400)

    # Fig: cumulative energy, both datasets
    fig, axs = plt.subplots(1, 2, figsize=(W2, 2.5), sharey=False)
    for ax, ds in zip(axs, ["fmnist", "sms"]):
        g = R["pm_gross"].get(ds)
        if g is None:
            continue
        for t in g["tiers"]:
            s = g["S"][t]
            ax.plot(Ns, (s["setup_j"][0] + Ns * s["infer_j"][0]) / 3600, STYLE[t], color=COLOR[t], label=LABEL[t])
        ax.set_xscale("log"); ax.set_yscale("log")
        ax.set_xlabel("Predictions $N$"); ax.set_title(DSNAME[ds], fontsize=8)
    axs[0].set_ylabel("Cumulative energy (Wh)")
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, ncol=7, loc="upper center", bbox_to_anchor=(0.5, 1.0), fontsize=7)
    fig.tight_layout(rect=(0, 0, 1, 0.86))
    fig.savefig(os.path.join(out, "figures", "cumulative.pdf")); plt.close(fig)

    # Fig: setup vs per-call energy plane (log-log), each tier a point, both datasets
    fig, axs = plt.subplots(1, 2, figsize=(W2, 2.0))
    for ax, ds in zip(axs, ["fmnist", "sms"]):
        g = R["pm_gross"].get(ds)
        if g is None:
            continue
        for t in g["tiers"]:
            s = g["S"][t]
            ax.errorbar(s["setup_j"][0], s["infer_j"][0] * 1e6, xerr=[[s["setup_j"][0] - s["setup_j"][1]], [s["setup_j"][2] - s["setup_j"][0]]],
                        yerr=[[(s["infer_j"][0] - s["infer_j"][1]) * 1e6], [(s["infer_j"][2] - s["infer_j"][0]) * 1e6]],
                        fmt="o", ms=5, color=COLOR[t], mec="white", mew=0.8, elinewidth=0.8)
            off = {"rf": (-5, 4, "right"), "svm": (5, -9, "left")}.get(t, (4, 3, "left"))
            ax.annotate(LABEL[t], (s["setup_j"][0], s["infer_j"][0] * 1e6), xytext=off[:2], textcoords="offset points",
                        fontsize=6.5, color="#0b0b0b", ha=off[2])
        ax.set_xscale("log"); ax.set_yscale("log")
        ax.set_xlabel("Setup energy $E_\\mathrm{prep}+E_\\mathrm{train}$ (J)"); ax.set_title(DSNAME[ds], fontsize=8)
    axs[0].set_ylabel("Energy per prediction ($\\mu$J)")
    fig.tight_layout(); fig.savefig(os.path.join(out, "figures", "plane.pdf")); plt.close(fig)

    # Fig: measured vs estimated (CodeCarbon / powermetrics), per phase type
    fig, ax = plt.subplots(figsize=(W1, 2.4))
    for ds, mk in [("fmnist", "o"), ("sms", "s")]:
        if ds not in S["main"]:
            continue
        for t, v in S["main"][ds]["tiers"].items():
            ax.scatter(v["train_gross_j"], v["cc_train_j"], marker=mk, s=18, color=COLOR[t], edgecolor="white", lw=0.5)
            ax.scatter(v["infer_gross_j"] * 1e3, v["cc_infer_j"] * 1e3, marker=mk, s=18, facecolor="none",
                       edgecolor=COLOR[t], lw=0.9)
    lim = ax.get_xlim()
    xs = np.logspace(-4, 4, 10)
    ax.plot(xs, xs, color="#8a8984", lw=0.8, ls="--")
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel("powermetrics (J; mJ per prediction)"); ax.set_ylabel("CodeCarbon estimate")
    ax.text(0.03, 0.92, "filled: training (J)\nopen: per prediction (mJ)\ncircle FMNIST, square SMS", transform=ax.transAxes,
            fontsize=6.5, va="top")
    fig.tight_layout(); fig.savefig(os.path.join(out, "figures", "cc_vs_pm.pdf")); plt.close(fig)

    # Fig: inference share at 1e6 (gross), grouped bars
    fig, ax = plt.subplots(figsize=(W1, 2.2))
    tiers = [t for t in LABEL if any(t in S["main"].get(ds, {}).get("tiers", {}) for ds in ["fmnist", "sms"])]
    x = np.arange(len(tiers)); w = 0.38
    for k, (ds, hatch) in enumerate([("fmnist", None), ("sms", "////")]):
        vals = [S["main"][ds]["tiers"].get(t, {}).get("infer_share_1e6", np.nan) * 100 for t in tiers]
        ax.bar(x + (k - 0.5) * w, vals, w - 0.03, color=[COLOR[t] for t in tiers], hatch=hatch,
               edgecolor="white", lw=0.5, label=DSNAME[ds])
    ax.set_xticks(x, [LABEL[t] for t in tiers], rotation=30, ha="right")
    ax.set_ylabel("Inference share at $N=10^6$ (%)"); ax.set_ylim(0, 100)
    ax.legend(fontsize=6.5, loc="lower right", handlelength=1.2)
    fig.tight_layout(); fig.savefig(os.path.join(out, "figures", "share.pdf")); plt.close(fig)

    # Fig: single vs batched per-prediction energy
    fig, ax = plt.subplots(figsize=(W1, 2.2))
    for k, (ds, hatch) in enumerate([("fmnist", None), ("sms", "////")]):
        if ds not in S["main"]:
            continue
        vals = [S["main"][ds]["tiers"].get(t, {}).get("batch_gain", np.nan) for t in tiers]
        ax.bar(x + (k - 0.5) * w, vals, w - 0.03, color=[COLOR[t] for t in tiers], hatch=hatch, edgecolor="white",
               lw=0.5, label=DSNAME[ds])
    ax.axhline(1, color="#8a8984", lw=0.8)
    ax.set_yscale("log"); ax.set_xticks(x, [LABEL[t] for t in tiers], rotation=30, ha="right")
    ax.set_ylabel("Single / batched energy\nper prediction")
    ax.legend(fontsize=6.5, handlelength=1.2)
    fig.tight_layout(); fig.savefig(os.path.join(out, "figures", "batching.pdf")); plt.close(fig)

    # Fig: regime map -- most probable energy-optimal tier vs N, per accuracy floor
    fig, axs = plt.subplots(1, 2, figsize=(W2, 1.65))
    used = []
    for ax, ds in zip(axs, ["fmnist", "sms"]):
        if ds not in S["main"]:
            continue
        reg, floors = S["main"][ds]["regime"], S["main"][ds]["floors"]
        logN = np.log10(REGIME_N)
        edges = np.concatenate([[logN[0]], (logN[1:] + logN[:-1]) / 2, [logN[-1]]])
        for k, f in enumerate(floors):
            rows = reg[str(f)]
            win, pw = [], []
            for row in rows:
                cand = {t: v for t, v in row.items() if t not in ("N", "none")}
                t = max(cand, key=cand.get)
                win.append(None if row["none"] > 0.5 else t)
                pw.append(cand[t])
            # one solid bar per run of identical winners; hatch cells where P(optimal) < 0.8
            start = 0
            for j in range(1, len(win) + 1):
                if j == len(win) or win[j] != win[start]:
                    t = win[start]
                    if t is not None:
                        ax.barh(k, edges[j] - edges[start], left=edges[start], height=0.72, color=COLOR[t], lw=0)
                        if t not in used:
                            used.append(t)
                        if edges[j] - edges[start] > 0.9:
                            ax.text((edges[start] + edges[j]) / 2, k, LABEL[t], ha="center", va="center",
                                    fontsize=6.5, color="white" if t in ("svm", "rf", "logreg", "cnn") else "#0b0b0b",
                                    bbox=None)
                    start = j
            start = None
            for j in range(len(win) + 1):
                low = j < len(win) and win[j] is not None and pw[j] < 0.8
                if low and start is None:
                    start = j
                if not low and start is not None:
                    ax.barh(k, edges[j] - edges[start], left=edges[start], height=0.72, facecolor="none",
                            edgecolor="white", hatch="////", lw=0)
                    start = None
        ax.set_yticks(range(len(floors)), ["any" if f == 0 else f"$\\geq${f:.2f}" for f in floors])
        ax.set_xticks(range(0, 10), [f"$10^{{{i}}}$" for i in range(0, 10)])
        ax.set_xlim(edges[0], edges[-1]); ax.invert_yaxis(); ax.grid(False)
        ax.set_xlabel("Predictions $N$"); ax.set_title(DSNAME[ds], fontsize=8)
    axs[0].set_ylabel("Accuracy floor")
    fig.tight_layout(); fig.savefig(os.path.join(out, "figures", "regime.pdf")); plt.close(fig)

    if Ra:
        fig, axs = plt.subplots(1, 4, figsize=(W2, 1.8), sharey=False)
        Nsm = np.logspace(0, 6, 300)
        for ax, ds in zip(axs, ["iris", "breast_cancer", "wine", "sms"]):
            g = Ra.get(ds)
            if g is None:
                continue
            for t in g["tiers"]:
                s = g["S"][t]
                ax.plot(Nsm, s["setup_j"][0] + Nsm * s["infer_j"][0], STYLE[t], color=COLOR[t], label=LABEL[t])
            ax.set_xscale("log"); ax.set_yscale("log"); ax.set_title(DSNAME[ds], fontsize=8)
            ax.set_xlabel("$N$")
        axs[0].set_ylabel("Cumulative energy (J)")
        h, l = axs[0].get_legend_handles_labels()
        fig.legend(h, l, ncol=7, loc="upper center", bbox_to_anchor=(0.5, 1.0), fontsize=7)
        fig.tight_layout(rect=(0, 0, 1, 0.82))
        fig.savefig(os.path.join(out, "figures", "decider.pdf")); plt.close(fig)


if __name__ == "__main__":
    main()
