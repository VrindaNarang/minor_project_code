"""Add-on run: tabular datasets and a zero-shot decision model (Strands Decider 2B).

Datasets: Iris, Breast Cancer Wisconsin (diagnostic), Wine (all bundled with
scikit-learn) and the SMS Spam Collection (same split as run_extended.py).

Trained tiers (scikit-learn): logistic regression, linear SVM, RBF SVM, k-NN,
random forest, MLP (one hidden layer of 128) on tabular data; logistic
regression and linear SVM on SMS (TF-IDF). The SMS tiers repeat two of the
main run's tiers so that the zero-shot model is compared within one session.

Zero-shot tier: Strands Decider 2B served locally (`strands-decider serve`,
separate venv). It has no training phase; loading the model is logged as a
one-off preparation phase. Each call sends one record as text with a fixed
template and a fixed set of answer options, and returns the chosen option.

Energy phases are logged exactly as in run_extended.py (CodeCarbon + phase log
for powermetrics). Preprocessing fits (scaler, TF-IDF) are tracked as `prep`.
"""
import argparse
import json
import math
import os
import subprocess
import time
import urllib.request
from datetime import datetime

import numpy as np
from sklearn.datasets import load_breast_cancer, load_iris, load_wine
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC, LinearSVC
from threadpoolctl import threadpool_limits

from common import CCTracker, describe_environment, save_json
from extended import SMS_TFIDF, Both, PhaseLog, load_sms
from run_experiment import CSVLog

DECIDER_MODEL = "StrandsAgents/strands-decider-2B-qwen3.5-v1-2610"
TAB_TIERS = ["logreg", "linsvm", "svm", "knn", "rf", "mlp"]
SMS_TIERS = ["logreg", "linsvm"]

# Fixed prompt templates and answer options (reported in the paper)
QUESTIONS = {
    "iris": ("Which species of iris flower do these measurements describe?",
             {"setosa": "Iris setosa", "versicolor": "Iris versicolor", "virginica": "Iris virginica"}),
    "breast_cancer": ("Based on these cell nucleus measurements from a breast mass biopsy, is the tumour "
                      "malignant or benign?", {"malignant": "malignant tumour", "benign": "benign tumour"}),
    "wine": ("These are chemical measurements of a wine from one of three cultivars grown in the same region "
             "of Italy. Which cultivar is it?",
             {"class_0": "cultivar 1", "class_1": "cultivar 2", "class_2": "cultivar 3"}),
    "sms": ("Is this SMS message spam or a normal message?", {"ham": "a normal message", "spam": "spam"}),
}


def parse():
    p = argparse.ArgumentParser()
    p.add_argument("--out", default="results_addon")
    p.add_argument("--data", default="data")
    p.add_argument("--runs", type=int, default=5)
    p.add_argument("--block-s", type=float, default=30.0, help="target length of a trained-tier block")
    p.add_argument("--decider-block-s", type=float, default=60.0)
    p.add_argument("--warmup", type=int, default=100)
    p.add_argument("--decider-warmup", type=int, default=10)
    p.add_argument("--idle-s", type=float, default=30.0)
    p.add_argument("--cooldown-s", type=float, default=60.0)
    p.add_argument("--threads", type=int, default=4)
    p.add_argument("--interval", type=float, default=1.0)
    p.add_argument("--country", default="IND")
    p.add_argument("--decider-python", default=os.path.expanduser("~/PrernaML/decider/.venv/bin/strands-decider"))
    p.add_argument("--decider-device", default="mps")
    p.add_argument("--port", type=int, default=8765)
    p.add_argument("--no-decider", action="store_true")
    p.add_argument("--eval-limit", type=int, default=0, help="limit decider test-set evaluation (testing only)")
    p.add_argument("--quick", action="store_true")
    a = p.parse_args()
    if a.quick:
        a.runs, a.block_s, a.decider_block_s, a.idle_s, a.cooldown_s = 1, 2.0, 4.0, 2.0, 1.0
        a.warmup, a.decider_warmup, a.eval_limit = 10, 2, a.eval_limit or 20
    return a


# ----------------------------------------------------------------------------- data
def tabular(name):
    loader = {"iris": load_iris, "breast_cancer": load_breast_cancer, "wine": load_wine}[name]
    d = loader()
    X, y = d.data.astype(np.float64), d.target
    tr, te = train_test_split(np.arange(len(y)), test_size=0.2, stratify=y, random_state=0)
    names = [str(n) for n in d.feature_names]
    labels = [str(t) for t in d.target_names]
    return {"X_train": X[tr], "y_train": y[tr], "X_test": X[te], "y_test": y[te],
            "features": names, "labels": labels}


def record_text(name, features, row):
    """Fixed template: one 'feature: value' pair per feature, as plain text."""
    lead = {"iris": "Iris flower measurements (cm)",
            "breast_cancer": "Breast mass cell nucleus measurements",
            "wine": "Wine chemical analysis"}[name]
    return lead + ": " + "; ".join(f"{f} = {v:.4g}" for f, v in zip(features, row)) + "."


def build(tier, seed):
    return {
        "logreg": lambda: LogisticRegression(max_iter=1000, random_state=seed),
        "linsvm": lambda: LinearSVC(C=1.0, random_state=seed),
        "svm": lambda: SVC(kernel="rbf", C=1.0, gamma="scale", random_state=seed),
        "knn": lambda: KNeighborsClassifier(n_neighbors=5),
        "rf": lambda: RandomForestClassifier(n_estimators=100, n_jobs=4, random_state=seed),
        "mlp": lambda: MLPClassifier(hidden_layer_sizes=(128,), max_iter=500, random_state=seed),
    }[tier]()


# -------------------------------------------------------------------------- decider
class Decider:
    def __init__(self, a, out):
        self.a, self.url = a, f"http://127.0.0.1:{a.port}/v1/systemone"
        self.log = open(os.path.join(out, "decider_server.log"), "w")
        self.proc = None

    def start(self):
        cmd = [self.a.decider_python, "serve", DECIDER_MODEL, "--port", str(self.a.port),
               "--device", self.a.decider_device]
        self.proc = subprocess.Popen(cmd, stdout=self.log, stderr=subprocess.STDOUT)
        t0 = time.time()
        while time.time() - t0 < 600:
            try:
                self.ask("sms", "hello")
                return
            except Exception:
                if self.proc.poll() is not None:
                    raise RuntimeError("decider server exited; see decider_server.log")
                time.sleep(1)
        raise RuntimeError("decider server did not become ready in 600 s")

    def ask(self, ds, state):
        q, opts = QUESTIONS[ds]
        body = {"state": state, "questions": {"label": {"type": "choice", "instructions": q, "criteria": opts}}}
        req = urllib.request.Request(self.url, data=json.dumps(body).encode(),
                                     headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=120) as r:
            resp = json.loads(r.read())
        return parse_choice(resp)

    def stop(self):
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()
            try:
                self.proc.wait(30)
            except subprocess.TimeoutExpired:
                self.proc.kill()


def parse_choice(resp):
    """Return (choice, confidence) from a /v1/systemone response, whatever the nesting."""
    def find(d):
        if isinstance(d, dict):
            if "choice" in d:
                return d
            for v in d.values():
                r = find(v)
                if r is not None:
                    return r
        if isinstance(d, list):
            for v in d:
                r = find(v)
                if r is not None:
                    return r
        return None
    hit = find(resp)
    if hit is None:
        raise ValueError(f"no choice in response: {str(resp)[:300]}")
    return str(hit["choice"]), hit.get("confidence")


# ------------------------------------------------------------------------------ main
def run_calls(fn, xs, m):
    n = len(xs)
    for i in range(m):
        fn(xs[i % n])


def calibrate(fn, xs, target_s, min_s=2.0, min_calls=5):
    run_calls(fn, xs, 2)
    k, t0 = 0, time.perf_counter()
    while time.perf_counter() - t0 < min_s or k < min_calls:
        fn(xs[k % len(xs)])
        k += 1
    per = (time.perf_counter() - t0) / k
    step = 100 if per < 0.01 else 10
    return max(step, int(math.ceil(target_s / per / step) * step)), per


def main():
    a = parse()
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    out = os.path.join(a.out, stamp + ("-quick" if a.quick else ""))
    os.makedirs(out, exist_ok=True)
    print(f"Writing results to {out}", flush=True)
    env = describe_environment(a.threads)
    env.update(args=vars(a), started=datetime.now().isoformat(), decider_model=DECIDER_MODEL,
               questions={k: [v[0], v[1]] for k, v in QUESTIONS.items()})
    save_json(env, os.path.join(out, "environment.json"))

    logs = {k: CSVLog(os.path.join(out, f"{k}.csv")) for k in ["train_runs", "inference_blocks", "idle", "decider"]}
    phases = PhaseLog(os.path.join(out, "phases.csv"))

    def tracked(ds, r, tier, kind, calls=None):
        return Both(CCTracker(a.country, a.interval, out), phases.phase(ds, r, tier, kind, calls, 1))

    data = {n: tabular(n) for n in ["iris", "breast_cancer", "wine"]}
    S = load_sms(a.data)
    data["sms"] = {"t_train": S["t_train"], "y_train": S["y_train"], "t_test": S["t_test"], "y_test": S["y_test"],
                   "labels": ["ham", "spam"]}
    texts = {}
    for n in ["iris", "breast_cancer", "wine"]:
        d = data[n]
        texts[n] = [record_text(n, d["features"], row) for row in d["X_test"]]
    texts["sms"] = list(S["t_test"])
    save_json({n: texts[n][:3] for n in texts}, os.path.join(out, "example_prompts.json"))

    block_calls = {}
    dec = None
    if not a.no_decider:
        dec = Decider(a, out)
        with tracked("-", -1, "decider", "load"):
            dec.start()
        print("decider ready", flush=True)
        # Accuracy once (the model is deterministic and has no training seed)
        for n in data:
            xs = texts[n] if not a.eval_limit else texts[n][:a.eval_limit]
            ys = data[n]["y_test"][:len(xs)]
            preds, confs, t0 = [], [], time.perf_counter()
            for s in xs:
                c, conf = dec.ask(n, s)
                preds.append(c)
                confs.append(conf)
            lab = data[n]["labels"]
            p_idx = np.array([lab.index(c) if c in lab else -1 for c in preds])
            acc = float((p_idx == ys).mean())
            f1 = float(f1_score(ys, p_idx, average="macro", labels=list(range(len(lab)))))
            np.save(os.path.join(out, f"test_preds_{n}_decider.npy"), p_idx)
            logs["decider"].write({"dataset": n, "n_test": len(xs), "test_acc": acc, "test_f1": f1,
                                   "invalid": int((p_idx < 0).sum()), "mean_conf": float(np.mean(
                                       [c for c in confs if c is not None])) if any(c is not None for c in confs)
                                   else None, "eval_s": time.perf_counter() - t0})
            print(f"  decider {n}: acc {acc:.4f} f1 {f1:.4f} ({len(xs)} test items)", flush=True)

    with threadpool_limits(a.threads):
        for r in range(a.runs):
            seed = 1000 + r
            print(f"\n=== Round {r + 1}/{a.runs}", flush=True)
            with phases.phase("-", r, "-", "cooldown"):
                time.sleep(a.cooldown_s)
            with tracked("-", r, "-", "idle") as b:
                time.sleep(a.idle_s)
            logs["idle"].write({"round": r, "when": "start", "phase_id": b.phase_id, **b.result})
            names = list(data)
            for n in names[r % len(names):] + names[:r % len(names)]:
                d = data[n]
                tiers = (SMS_TIERS if n == "sms" else TAB_TIERS) + ([] if dec is None else ["decider"])
                tiers = tiers[r % len(tiers):] + tiers[:r % len(tiers)]
                for t in tiers:
                    if t == "decider":
                        fn = lambda s, n=n: dec.ask(n, s)
                        xs, target, wu = texts[n], a.decider_block_s, a.decider_warmup
                    else:
                        with tracked(n, r, t, "prep") as bp:
                            if n == "sms":
                                from sklearn.feature_extraction.text import TfidfVectorizer
                                pre = TfidfVectorizer(**SMS_TFIDF)
                                Xtr = pre.fit_transform(d["t_train"])
                            else:
                                pre = StandardScaler()
                                Xtr = pre.fit_transform(d["X_train"])
                        with tracked(n, r, t, "train") as bt:
                            clf = build(t, seed)
                            clf.fit(Xtr, d["y_train"])
                        Xte = pre.transform(d["t_test"] if n == "sms" else d["X_test"])
                        p = clf.predict(Xte)
                        acc = float((p == d["y_test"]).mean())
                        f1 = float(f1_score(d["y_test"], p, average="macro"))
                        if hasattr(clf, "n_jobs") and t == "rf":
                            clf.n_jobs = 1
                        logs["train_runs"].write({"dataset": n, "round": r, "seed": seed, "tier": t,
                                                  "test_acc": acc, "test_f1": f1,
                                                  "prep_phase_id": bp.phase_id, "phase_id": bt.phase_id,
                                                  "prep_duration_s": bp.result["duration_s"],
                                                  "prep_energy_kwh": bp.result["energy_kwh"], **bt.result})
                        if r == 0:
                            np.save(os.path.join(out, f"test_preds_{n}_{t}.npy"), p)
                        if n == "sms":
                            xs = list(d["t_test"])
                            fn = lambda s, pre=pre, clf=clf: clf.predict(pre.transform([s]))
                        else:
                            xs = [row.reshape(1, -1) for row in d["X_test"]]
                            fn = lambda x, pre=pre, clf=clf: clf.predict(pre.transform(x))
                        target, wu = a.block_s, a.warmup
                    key = f"{n}/{t}"
                    if key not in block_calls:
                        block_calls[key], per = calibrate(fn, xs, target)
                        print(f"    calibrated {key}: {per * 1e3:.3f} ms/call -> M = {block_calls[key]:,}", flush=True)
                    m = block_calls[key]
                    run_calls(fn, xs, wu)
                    with tracked(n, r, t, "infer_single", m) as b:
                        run_calls(fn, xs, m)
                    logs["inference_blocks"].write({"dataset": n, "round": r, "tier": t, "mode": "single", "calls": m,
                                                    "batch": 1, "predictions": m, "phase_id": b.phase_id, **b.result})
                    print(f"  [{n}] {t:8s} {b.result['duration_s']:6.1f}s  {m:,} calls", flush=True)
        with tracked("-", a.runs, "-", "idle") as b:
            time.sleep(a.idle_s)
        logs["idle"].write({"round": a.runs, "when": "end", "phase_id": b.phase_id, **b.result})
    if dec:
        dec.stop()
    env["finished"] = datetime.now().isoformat()
    env["block_calls"] = block_calls
    env["power_source_end"] = subprocess.run(["pmset", "-g", "batt"], capture_output=True, text=True).stdout
    save_json(env, os.path.join(out, "environment.json"))
    print("\nDone.", flush=True)


if __name__ == "__main__":
    main()
